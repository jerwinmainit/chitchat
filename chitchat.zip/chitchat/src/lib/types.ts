export interface MyProfile {
  id: string
  nickname: string
  birth_date: string
  gender_identity: string
  orientation: string
  interested_in: string[]
  connection_types: string[]
  bio: string
  interests: string[]
  avatar_url: string | null
  area: string | null
  show_gender: boolean
  show_orientation: boolean
  show_area: boolean
  show_online: boolean
  show_photo: boolean
  allow_messages: boolean
  require_match_to_chat: boolean
  last_seen: string
  created_at: string
}

export interface PublicProfile {
  id: string
  nickname: string
  age: number
  gender_identity: string | null
  orientation: string | null
  bio: string
  interests: string[]
  connection_types: string[]
  avatar_url: string | null
  area: string | null
  is_online: boolean
}

export interface Conversation {
  id: string
  user_a: string
  user_b: string
  last_message_at: string
  last_message_preview: string
  a_hidden: boolean
  b_hidden: boolean
}

export interface Message {
  id: string
  conversation_id: string
  sender_id: string
  body: string | null
  image_path: string | null
  created_at: string
  delivered_at: string | null
  read_at: string | null
}

export interface AppNotification {
  id: string
  user_id: string
  type: 'like' | 'match' | 'message' | 'system'
  actor_id: string | null
  text: string
  read: boolean
  created_at: string
}

export interface ReportRow {
  id: string
  reported_nickname: string
  reason: string
  details: string
  status: string
  created_at: string
}
