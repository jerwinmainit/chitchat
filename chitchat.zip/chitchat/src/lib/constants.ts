export const GENDER_IDENTITIES = [
  'Male',
  'Female',
  'Gay man',
  'Lesbian',
  'Bisexual',
  'Transgender',
  'Non-binary',
  'Other',
  'Prefer not to say',
]

// Orientation is separate from gender identity.
export const ORIENTATIONS = [
  'Straight',
  'Gay',
  'Lesbian',
  'Bisexual',
  'Pansexual',
  'Asexual',
  'Queer',
  'Questioning',
  'Other',
  'Prefer not to say',
]

// "Who do you want to meet" options (multi-select)
export const INTERESTED_IN = [...GENDER_IDENTITIES.filter((g) => g !== 'Prefer not to say'), 'Everyone']

export const CONNECTION_TYPES = ['Friends', 'Dating', 'Relationship', 'Chat only', 'Something casual']

export const INTEREST_OPTIONS = [
  'Music', 'Movies', 'Gaming', 'Travel', 'Food', 'Coffee', 'Fitness', 'Reading',
  'Anime', 'Art', 'Photography', 'Dancing', 'Karaoke', 'Beach', 'Hiking', 'Pets',
  'Tech', 'Fashion', 'Cooking', 'Sports',
]

export const REPORT_REASONS: { value: string; label: string }[] = [
  { value: 'harassment', label: 'Harassment or bullying' },
  { value: 'scam', label: 'Scam or fraud' },
  { value: 'impersonation', label: 'Impersonation / fake profile' },
  { value: 'inappropriate_content', label: 'Inappropriate content' },
  { value: 'underage', label: 'Appears to be under 18' },
  { value: 'spam', label: 'Spam' },
  { value: 'other', label: 'Something else' },
]

export const MIN_AGE = 18
