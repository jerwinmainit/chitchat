import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

export const isConfigured = Boolean(url && anon && !url.includes('YOUR-PROJECT'))

// Only the public "anon" key is used here. It is safe in the browser because
// Row Level Security (see supabase/schema.sql) protects all data.
export const supabase = createClient(
  isConfigured ? (url as string) : 'https://placeholder.supabase.co',
  isConfigured ? (anon as string) : 'placeholder-key',
  { auth: { persistSession: true, autoRefreshToken: true } },
)
