import { supabase } from './supabase'
import type { PublicProfile } from './types'

export async function getPublicProfiles(ids: string[]): Promise<Record<string, PublicProfile>> {
  const map: Record<string, PublicProfile> = {}
  if (ids.length === 0) return map
  const { data, error } = await supabase.from('public_profiles').select('*').in('id', ids)
  if (error) throw error
  for (const p of (data ?? []) as PublicProfile[]) map[p.id] = p
  return map
}

export async function isMatched(me: string, other: string): Promise<boolean> {
  const a = me < other ? me : other
  const b = me < other ? other : me
  const { data } = await supabase.from('matches').select('id').eq('user_a', a).eq('user_b', b).maybeSingle()
  return Boolean(data)
}

export async function sendLike(me: string, target: string, action: 'like' | 'pass'): Promise<boolean> {
  const { error } = await supabase.from('likes').upsert(
    { liker_id: me, liked_id: target, action },
    { onConflict: 'liker_id,liked_id' },
  )
  if (error) throw error
  return action === 'like' ? isMatched(me, target) : false
}

export async function toggleFavorite(me: string, target: string, on: boolean) {
  if (on) {
    const { error } = await supabase.from('favorites').insert({ user_id: me, target_id: target })
    if (error && !/duplicate/i.test(error.message)) throw error
  } else {
    const { error } = await supabase.from('favorites').delete().eq('user_id', me).eq('target_id', target)
    if (error) throw error
  }
}

export async function openConversation(target: string): Promise<string> {
  const { data, error } = await supabase.rpc('start_conversation', { target })
  if (error) throw error
  return data as string
}
