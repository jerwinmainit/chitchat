import { useState } from 'react'
import { Modal } from './ui'
import { supabase } from '../lib/supabase'
import { REPORT_REASONS } from '../lib/constants'
import { errMsg } from '../lib/utils'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

export default function ReportModal({
  open, onClose, targetId, targetName, onBlocked,
}: { open: boolean; onClose: () => void; targetId: string; targetName: string; onBlocked?: () => void }) {
  const { session } = useAuth()
  const toast = useToast()
  const [reason, setReason] = useState('harassment')
  const [details, setDetails] = useState('')
  const [alsoBlock, setAlsoBlock] = useState(true)
  const [busy, setBusy] = useState(false)

  async function submit() {
    if (!session) return
    setBusy(true)
    const { error } = await supabase.from('reports').insert({
      reporter_id: session.user.id, reported_id: targetId, reported_nickname: targetName, reason, details: details.trim(),
    })
    if (error) { setBusy(false); toast(errMsg(error), 'error'); return }
    if (alsoBlock) {
      const { error: be } = await supabase.from('blocks').insert({ blocker_id: session.user.id, blocked_id: targetId })
      if (be && !/duplicate/i.test(be.message)) toast(errMsg(be), 'error')
      else onBlocked?.()
    }
    setBusy(false)
    toast('Report sent. Salamat — our team will review it.', 'success')
    setDetails('')
    onClose()
  }

  return (
    <Modal open={open} onClose={onClose} title={`Report ${targetName}`}>
      <label className="label" htmlFor="reason">What happened?</label>
      <select id="reason" className="input" value={reason} onChange={(e) => setReason(e.target.value)}>
        {REPORT_REASONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
      </select>
      <label className="label mt-4" htmlFor="details">Details (optional)</label>
      <textarea id="details" className="input min-h-[90px]" maxLength={1000} value={details} onChange={(e) => setDetails(e.target.value)} placeholder="Tell us what happened. Don't include passwords or financial info." />
      <label className="mt-4 flex items-center gap-2 text-sm">
        <input type="checkbox" checked={alsoBlock} onChange={(e) => setAlsoBlock(e.target.checked)} className="h-4 w-4 accent-violet" />
        Also block this user
      </label>
      <div className="mt-5 flex gap-3">
        <button className="btn-ghost flex-1" onClick={onClose}>Cancel</button>
        <button className="btn-primary flex-1" disabled={busy} onClick={submit}>{busy ? 'Sending…' : 'Submit report'}</button>
      </div>
    </Modal>
  )
}
