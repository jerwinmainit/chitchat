import { useCallback, useEffect, useState } from 'react'
import { NavLink, Outlet, Link, useLocation } from 'react-router-dom'
import { Logo, ThemeToggle } from './ui'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

const NAV = [
  { to: '/discover', label: 'Discover', icon: '🔥' },
  { to: '/likes', label: 'Likes', icon: '💜' },
  { to: '/chats', label: 'Chats', icon: '💬' },
  { to: '/profile', label: 'Profile', icon: '👤' },
]

export default function Layout() {
  const { session, profile } = useAuth()
  const loc = useLocation()
  const [notifCount, setNotifCount] = useState(0)
  const [unreadMsgs, setUnreadMsgs] = useState(0)

  const refreshCounts = useCallback(async () => {
    if (!session) return
    const uid = session.user.id
    void supabase.rpc('mark_delivered') // messages reaching an online user count as "delivered"
    const [n, m] = await Promise.all([
      supabase.from('notifications').select('id', { count: 'exact', head: true }).eq('user_id', uid).eq('read', false),
      supabase.from('messages').select('id', { count: 'exact', head: true }).neq('sender_id', uid).is('read_at', null),
    ])
    setNotifCount(n.count ?? 0)
    setUnreadMsgs(m.count ?? 0)
  }, [session])

  useEffect(() => {
    void refreshCounts()
    if (!session) return
    const ch = supabase
      .channel('layout-counters')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, () => void refreshCounts())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => void refreshCounts())
      .subscribe()
    return () => { void supabase.removeChannel(ch) }
  }, [session, refreshCounts, loc.pathname])

  const badge = (to: string) => (to === '/chats' ? unreadMsgs : 0)

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl">
      {/* Desktop / tablet sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col justify-between border-r border-slate-200 p-5 dark:border-white/10 md:flex">
        <div className="space-y-8">
          <Logo />
          <nav className="space-y-1" aria-label="Main">
            {NAV.map((n) => (
              <NavLink key={n.to} to={n.to} className={({ isActive }) => `flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition ${isActive ? 'bg-brand text-white shadow-lg shadow-violet/30' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10'}`}>
                <span className="text-lg">{n.icon}</span>
                <span className="flex-1">{n.label}</span>
                {badge(n.to) > 0 && <span className="rounded-full bg-hot px-2 py-0.5 text-xs text-white">{badge(n.to)}</span>}
              </NavLink>
            ))}
            <NavLink to="/notifications" className={({ isActive }) => `flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition ${isActive ? 'bg-brand text-white' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10'}`}>
              <span className="text-lg">🔔</span><span className="flex-1">Notifications</span>
              {notifCount > 0 && <span className="rounded-full bg-hot px-2 py-0.5 text-xs text-white">{notifCount}</span>}
            </NavLink>
            <NavLink to="/settings" className={({ isActive }) => `flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition ${isActive ? 'bg-brand text-white' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10'}`}>
              <span className="text-lg">⚙️</span>Settings & privacy
            </NavLink>
          </nav>
        </div>
        <div className="flex items-center justify-between">
          <span className="truncate text-sm font-medium">@{profile?.nickname}</span>
          <ThemeToggle />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Mobile top bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-200 bg-slate-50/90 px-4 py-3 backdrop-blur dark:border-white/10 dark:bg-navy-950/90 md:justify-end">
          <div className="md:hidden"><Logo size="sm" /></div>
          <div className="flex items-center gap-2">
            <Link to="/notifications" className="btn-ghost relative h-10 w-10 !p-0 text-lg md:hidden" aria-label={`Notifications${notifCount ? ` (${notifCount} new)` : ''}`}>
              🔔
              {notifCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-hot px-1 text-[10px] font-bold text-white">{notifCount}</span>}
            </Link>
            <Link to="/settings" className="btn-ghost h-10 w-10 !p-0 text-lg md:hidden" aria-label="Settings">⚙️</Link>
            <span className="md:hidden"><ThemeToggle /></span>
          </div>
        </header>

        <main className="flex-1 px-4 pb-28 pt-5 md:pb-10">
          <div className="mx-auto w-full max-w-xl"><Outlet /></div>
        </main>

        {/* Mobile bottom navigation */}
        <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur dark:border-white/10 dark:bg-navy-900/95 md:hidden" aria-label="Main">
          <ul className="mx-auto grid max-w-xl grid-cols-4">
            {NAV.map((n) => (
              <li key={n.to}>
                <NavLink to={n.to} className={({ isActive }) => `relative flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-semibold ${isActive ? 'text-gradient' : 'text-slate-500'}`}>
                  {({ isActive }) => (
                    <>
                      <span className={`text-xl transition ${isActive ? 'scale-110' : 'opacity-70 grayscale'}`}>{n.icon}</span>
                      {n.label}
                      {badge(n.to) > 0 && <span className="absolute right-[28%] top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-hot px-1 text-[9px] font-bold text-white">{badge(n.to)}</span>}
                    </>
                  )}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  )
}
