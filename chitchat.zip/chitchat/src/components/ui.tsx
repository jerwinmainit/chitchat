import { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useTheme } from '../context/ThemeContext'
import { gradientFor } from '../lib/utils'

export function Logo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const cls = size === 'lg' ? 'text-4xl' : size === 'sm' ? 'text-lg' : 'text-2xl'
  return (
    <Link to="/" className={`inline-flex items-center gap-2 font-extrabold tracking-tight ${cls}`} aria-label="ChitChat home">
      <span className="inline-flex h-[1.4em] w-[1.4em] items-center justify-center rounded-xl bg-brand text-[0.7em] text-white shadow-lg shadow-violet/40">💬</span>
      <span className="text-gradient">ChitChat</span>
    </Link>
  )
}

export function ThemeToggle() {
  const { theme, toggle } = useTheme()
  return (
    <button
      onClick={toggle}
      className="btn-ghost h-10 w-10 !p-0 text-lg"
      aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
    >
      {theme === 'dark' ? '☀️' : '🌙'}
    </button>
  )
}

export function Spinner({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-sm text-slate-500" role="status">
      <div className="h-9 w-9 animate-spin rounded-full border-4 border-violet/30 border-t-violet" />
      {label}
    </div>
  )
}

export function FullScreenSpinner() {
  return <div className="flex min-h-screen items-center justify-center"><Spinner /></div>
}

export function EmptyState({ icon, title, text, action }: { icon: string; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="card mx-auto my-8 flex max-w-md animate-rise flex-col items-center gap-3 p-8 text-center">
      <div className="text-5xl">{icon}</div>
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="text-sm text-slate-500 dark:text-slate-400">{text}</p>
      {action}
    </div>
  )
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="mx-auto my-6 max-w-md rounded-2xl border border-red-500/40 bg-red-500/10 p-4 text-center text-sm text-red-500" role="alert">
      <p>{message}</p>
      {onRetry && <button onClick={onRetry} className="btn-ghost mt-3">Try again</button>}
    </div>
  )
}

export function Avatar({ url, name, size = 48, online }: { url?: string | null; name: string; size?: number; online?: boolean }) {
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      {url ? (
        <img src={url} alt={`${name}'s photo`} className="h-full w-full rounded-full object-cover" loading="lazy" />
      ) : (
        <div
          className="flex h-full w-full items-center justify-center rounded-full font-bold text-white"
          style={{ background: gradientFor(name), fontSize: size * 0.4 }}
          aria-label={`${name}'s avatar`}
        >
          {name.slice(0, 1).toUpperCase()}
        </div>
      )}
      {online && <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white bg-emerald-500 dark:border-navy-900" title="Online" />}
    </div>
  )
}

export function ChipSelect({
  options, value, onChange, single = false,
}: { options: string[]; value: string[]; onChange: (v: string[]) => void; single?: boolean }) {
  const toggle = (o: string) => {
    if (single) return onChange([o])
    onChange(value.includes(o) ? value.filter((x) => x !== o) : [...value, o])
  }
  return (
    <div className="flex flex-wrap gap-2" role="group">
      {options.map((o) => (
        <button type="button" key={o} onClick={() => toggle(o)} aria-pressed={value.includes(o)} className={`chip ${value.includes(o) ? 'chip-on' : 'hover:bg-slate-100 dark:hover:bg-white/10'}`}>
          {o}
        </button>
      ))}
    </div>
  )
}

export function Switch({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-4 py-3">
      <span>
        <span className="block text-sm font-medium">{label}</span>
        {hint && <span className="hint">{hint}</span>}
      </span>
      <button
        type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)}
        className={`relative h-7 w-12 shrink-0 rounded-full transition ${checked ? 'bg-brand' : 'bg-slate-300 dark:bg-white/20'}`}
      >
        <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
      </button>
    </label>
  )
}

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center bg-black/60 p-0 sm:items-center sm:p-4" onClick={onClose} role="dialog" aria-modal="true" aria-label={title}>
      <div className="card max-h-[90vh] w-full max-w-md animate-rise overflow-y-auto rounded-b-none p-5 sm:rounded-b-3xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="text-2xl leading-none text-slate-400 hover:text-slate-200" aria-label="Close">×</button>
        </div>
        {children}
      </div>
    </div>
  )
}
