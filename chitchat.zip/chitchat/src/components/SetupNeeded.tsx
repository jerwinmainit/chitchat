export default function SetupNeeded() {
  return (
    <div className="mx-auto flex min-h-screen max-w-lg items-center p-6">
      <div className="card p-6">
        <h1 className="text-2xl font-extrabold">Almost there! 🛠️</h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          ChitChat is not connected to Supabase yet. Walay problema — follow these steps:
        </p>
        <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm">
          <li>Create a free project at supabase.com.</li>
          <li>Run <code>supabase/schema.sql</code> in the Supabase SQL Editor.</li>
          <li>Copy <code>.env.example</code> to <code>.env</code> and paste your Project URL and anon key.</li>
          <li>Restart <code>npm run dev</code> (or add the same two variables in Vercel, then redeploy).</li>
        </ol>
        <p className="mt-4 text-xs text-slate-500">The full guide is in README.md.</p>
      </div>
    </div>
  )
}
