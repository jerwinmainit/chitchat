import { Link } from 'react-router-dom'
import type { PublicProfile } from '../lib/types'
import { gradientFor } from '../lib/utils'

interface Props {
  p: PublicProfile
  isFavorite?: boolean
  busy?: boolean
  onLike?: () => void
  onPass?: () => void
  onFavorite?: () => void
  onChat?: () => void
}

export default function ProfileCard({ p, isFavorite, busy, onLike, onPass, onFavorite, onChat }: Props) {
  return (
    <article className="card animate-rise overflow-hidden">
      <div className="relative h-72 w-full sm:h-80" style={{ background: p.avatar_url ? undefined : gradientFor(p.nickname) }}>
        {p.avatar_url ? (
          <img src={p.avatar_url} alt={`${p.nickname}'s profile photo`} className="h-full w-full object-cover" loading="lazy" />
        ) : (
          <div className="flex h-full items-center justify-center text-7xl font-black text-white/90">{p.nickname.slice(0, 1).toUpperCase()}</div>
        )}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-4 pt-16 text-white">
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-extrabold">{p.nickname}, {p.age}</h3>
            {p.is_online && <span className="flex items-center gap-1 rounded-full bg-emerald-500/90 px-2 py-0.5 text-[10px] font-bold uppercase">● online</span>}
          </div>
          <div className="mt-1 flex flex-wrap gap-x-3 text-xs text-white/80">
            {p.gender_identity && <span>{p.gender_identity}</span>}
            {p.orientation && <span>{p.orientation}</span>}
            {p.area && <span>📍 {p.area}</span>}
          </div>
        </div>
      </div>

      <div className="space-y-3 p-4">
        {p.bio ? <p className="text-sm text-slate-700 dark:text-slate-300">{p.bio}</p> : <p className="text-sm italic text-slate-400">No bio yet.</p>}
        {p.interests.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {p.interests.slice(0, 6).map((i) => <span key={i} className="chip !py-1">{i}</span>)}
          </div>
        )}
        {p.connection_types.length > 0 && (
          <p className="text-xs text-slate-500">Looking for: {p.connection_types.join(' · ')}</p>
        )}

        <div className="flex items-center justify-between gap-2 pt-1">
          {onPass && (
            <button disabled={busy} onClick={onPass} className="btn-ghost h-12 w-12 !p-0 text-xl" aria-label={`Pass on ${p.nickname}`} title="Pass">✕</button>
          )}
          {onFavorite && (
            <button disabled={busy} onClick={onFavorite} className="btn-ghost h-12 w-12 !p-0 text-xl" aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'} title="Favorite">
              {isFavorite ? '⭐' : '☆'}
            </button>
          )}
          {onLike && (
            <button disabled={busy} onClick={onLike} className="btn-primary h-14 w-14 !p-0 text-2xl" aria-label={`Like ${p.nickname}`} title="Like">♥</button>
          )}
          {onChat && (
            <button disabled={busy} onClick={onChat} className="btn-ghost h-12 w-12 !p-0 text-xl" aria-label={`Chat with ${p.nickname}`} title="Start chatting">💬</button>
          )}
          <Link to={`/u/${p.id}`} className="btn-ghost h-12 !px-4 text-xs">View profile</Link>
        </div>
      </div>
    </article>
  )
}
