import { createContext, useCallback, useContext, useState, ReactNode } from 'react'

type Kind = 'success' | 'error' | 'info'
interface T { id: number; kind: Kind; text: string }
const Ctx = createContext<(text: string, kind?: Kind) => void>(() => {})

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<T[]>([])

  const push = useCallback((text: string, kind: Kind = 'info') => {
    const id = Date.now() + Math.random()
    setItems((x) => [...x, { id, kind, text }])
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), 4000)
  }, [])

  const color = { success: 'bg-emerald-600', error: 'bg-red-600', info: 'bg-violet' }

  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-3 z-[100] flex flex-col items-center gap-2 px-4" role="status" aria-live="polite">
        {items.map((i) => (
          <div key={i.id} className={`pointer-events-auto max-w-sm animate-pop rounded-2xl px-4 py-3 text-sm font-medium text-white shadow-xl ${color[i.kind]}`}>
            {i.text}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  )
}

export const useToast = () => useContext(Ctx)
