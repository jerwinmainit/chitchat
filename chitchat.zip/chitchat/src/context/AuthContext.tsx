import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase, isConfigured } from '../lib/supabase'
import type { MyProfile } from '../lib/types'

interface AuthState {
  session: Session | null
  profile: MyProfile | null
  loading: boolean
  refreshProfile: () => Promise<void>
  signOut: () => Promise<void>
}

const Ctx = createContext<AuthState>({
  session: null, profile: null, loading: true, refreshProfile: async () => {}, signOut: async () => {},
})

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<MyProfile | null>(null)
  const [loading, setLoading] = useState(true)

  const loadProfile = useCallback(async (uid: string | undefined) => {
    if (!uid) { setProfile(null); return }
    const { data } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle()
    setProfile((data as MyProfile) ?? null)
  }, [])

  useEffect(() => {
    if (!isConfigured) { setLoading(false); return }
    let mounted = true
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return
      setSession(data.session)
      await loadProfile(data.session?.user.id)
      if (mounted) setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s)
      // defer to avoid deadlocks inside the auth callback
      setTimeout(() => { void loadProfile(s?.user.id) }, 0)
    })
    return () => { mounted = false; sub.subscription.unsubscribe() }
  }, [loadProfile])

  // "online" heartbeat (only visible to others if the user enabled it)
  useEffect(() => {
    if (!session) return
    const uid = session.user.id
    const beat = () => { void supabase.from('profiles').update({ last_seen: new Date().toISOString() }).eq('id', uid) }
    beat()
    const t = setInterval(beat, 60_000)
    const onVis = () => { if (document.visibilityState === 'visible') beat() }
    document.addEventListener('visibilitychange', onVis)
    return () => { clearInterval(t); document.removeEventListener('visibilitychange', onVis) }
  }, [session])

  const value: AuthState = {
    session, profile, loading,
    refreshProfile: async () => { await loadProfile(session?.user.id) },
    signOut: async () => { await supabase.auth.signOut(); setProfile(null) },
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export const useAuth = () => useContext(Ctx)
