import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { ReactNode } from 'react'
import { useAuth } from './context/AuthContext'
import { isConfigured } from './lib/supabase'
import { FullScreenSpinner } from './components/ui'
import Layout from './components/Layout'
import SetupNeeded from './components/SetupNeeded'
import Landing from './pages/Landing'
import SignUp from './pages/SignUp'
import Login from './pages/Login'
import Discover from './pages/Discover'
import Profile from './pages/Profile'
import Matches from './pages/Matches'
import Chats from './pages/Chats'
import ChatRoom from './pages/ChatRoom'
import Notifications from './pages/Notifications'
import EditProfile from './pages/EditProfile'
import Settings from './pages/Settings'
import Safety from './pages/Safety'
import Guidelines from './pages/Guidelines'

function Protected({ children }: { children: ReactNode }) {
  const { session, loading } = useAuth()
  const loc = useLocation()
  if (loading) return <FullScreenSpinner />
  if (!session) return <Navigate to="/login" state={{ from: loc.pathname }} replace />
  return <>{children}</>
}

function PublicOnly({ children }: { children: ReactNode }) {
  const { session, loading } = useAuth()
  if (loading) return <FullScreenSpinner />
  if (session) return <Navigate to="/discover" replace />
  return <>{children}</>
}

export default function App() {
  if (!isConfigured) return <SetupNeeded />
  return (
    <Routes>
      <Route path="/" element={<PublicOnly><Landing /></PublicOnly>} />
      <Route path="/signup" element={<PublicOnly><SignUp /></PublicOnly>} />
      <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
      <Route path="/guidelines" element={<Guidelines />} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route path="/discover" element={<Discover />} />
        <Route path="/likes" element={<Matches />} />
        <Route path="/chats" element={<Chats />} />
        <Route path="/chats/:id" element={<ChatRoom />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/u/:id" element={<Profile />} />
        <Route path="/profile/edit" element={<EditProfile />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/safety" element={<Safety />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
