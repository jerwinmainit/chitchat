import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { AppNotification, PublicProfile } from '../lib/types'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, EmptyState, ErrorBox, Spinner } from '../components/ui'
import { getPublicProfiles } from '../lib/api'
import { errMsg, timeAgo } from '../lib/utils'

const ICON = { like: '💜', match: '🎉', message: '💬', system: '📢' }

export default function Notifications() {
  const { session } = useAuth()
  const me = session!.user.id
  const nav = useNavigate()
  const toast = useToast()
  const [items, setItems] = useState<AppNotification[]>([])
  const [people, setPeople] = useState<Record<string, PublicProfile>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true)
    setError('')
    try {
      const { data, error: err } = await supabase.from('notifications').select('*').eq('user_id', me).order('created_at', { ascending: false }).limit(60)
      if (err) throw err
      const list = data as AppNotification[]
      setItems(list)
      setPeople(await getPublicProfiles([...new Set(list.map((n) => n.actor_id).filter(Boolean) as string[])]))
    } catch (e) { setError(errMsg(e)) } finally { setLoading(false) }
  }, [me])

  useEffect(() => {
    void load()
    const ch = supabase.channel('notif-page')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${me}` }, () => void load(true))
      .subscribe()
    return () => { void supabase.removeChannel(ch) }
  }, [load, me])

  async function markAll() {
    const { error: err } = await supabase.from('notifications').update({ read: true }).eq('user_id', me).eq('read', false)
    if (err) return toast(errMsg(err), 'error')
    setItems((x) => x.map((n) => ({ ...n, read: true })))
  }

  async function open(n: AppNotification) {
    if (!n.read) {
      await supabase.from('notifications').update({ read: true }).eq('id', n.id)
      setItems((x) => x.map((i) => (i.id === n.id ? { ...i, read: true } : i)))
    }
    nav(n.type === 'message' ? '/chats' : '/likes')
  }

  async function clearAll() {
    if (!window.confirm('Delete all notifications?')) return
    const { error: err } = await supabase.from('notifications').delete().eq('user_id', me)
    if (err) return toast(errMsg(err), 'error')
    setItems([])
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-black">Notifications</h1>
        {items.length > 0 && (
          <div className="flex gap-2">
            <button className="btn-ghost !px-3 !py-1.5 text-xs" onClick={markAll}>Mark all read</button>
            <button className="btn-ghost !px-3 !py-1.5 text-xs" onClick={clearAll}>Clear</button>
          </div>
        )}
      </div>
      {loading ? <Spinner /> : error ? <ErrorBox message={error} onRetry={() => load()} /> : items.length === 0 ? (
        <EmptyState icon="🔔" title="Nothing new" text="Likes, matches and new messages will show up here." />
      ) : (
        <ul className="space-y-2">
          {items.map((n) => {
            const who = n.actor_id ? people[n.actor_id] : undefined
            return (
              <li key={n.id}>
                <button onClick={() => open(n)} className={`card flex w-full animate-rise items-center gap-3 p-3 text-left transition hover:bg-slate-50 dark:hover:bg-white/5 ${n.read ? 'opacity-70' : 'border-violet/50'}`}>
                  {who ? <Avatar url={who.avatar_url} name={who.nickname} size={44} /> : <span className="flex h-11 w-11 items-center justify-center rounded-full bg-violet/20 text-xl">{ICON[n.type]}</span>}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{ICON[n.type]} {who ? (n.type === 'match' ? `You matched with ${who.nickname}!` : n.type === 'message' ? `${who.nickname} sent you a message` : `${who.nickname} liked you`) : n.text}</p>
                    <p className="text-xs text-slate-500">{timeAgo(n.created_at)}</p>
                  </div>
                  {!n.read && <span className="h-2.5 w-2.5 rounded-full bg-hot" aria-label="Unread" />}
                </button>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
