import { ChangeEvent, FormEvent, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, ChipSelect, Switch } from '../components/ui'
import { CONNECTION_TYPES, GENDER_IDENTITIES, INTERESTED_IN, INTEREST_OPTIONS, ORIENTATIONS } from '../lib/constants'
import { NICKNAME_RE, errMsg } from '../lib/utils'

export default function EditProfile() {
  const { profile, session, refreshProfile } = useAuth()
  const nav = useNavigate()
  const toast = useToast()
  const p = profile!
  const [f, setF] = useState({
    nickname: p.nickname, bio: p.bio, area: p.area ?? '', avatar_url: p.avatar_url,
    gender: [p.gender_identity], orientation: [p.orientation],
    interested_in: p.interested_in, connection_types: p.connection_types,
    interests: p.interests, customInterest: '',
    show_gender: p.show_gender, show_orientation: p.show_orientation, show_area: p.show_area,
  })
  const [busy, setBusy] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const fileRef = useRef<HTMLInputElement>(null)
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }))

  async function onPhoto(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) return toast('Only JPG, PNG or WebP photos are allowed.', 'error')
    if (file.size > 3 * 1024 * 1024) return toast('Photo is too large (max 3 MB).', 'error')
    setUploading(true)
    try {
      const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg'
      const path = `${session!.user.id}/avatar-${Date.now()}.${ext}`
      const up = await supabase.storage.from('avatars').upload(path, file, { contentType: file.type, cacheControl: '3600' })
      if (up.error) throw up.error
      const { data } = supabase.storage.from('avatars').getPublicUrl(path)
      set('avatar_url', data.publicUrl)
      toast('Photo uploaded. Don’t forget to save!', 'info')
    } catch (err) { toast(errMsg(err), 'error') } finally { setUploading(false) }
  }

  function addCustom() {
    const v = f.customInterest.trim().slice(0, 24)
    if (!v) return
    if (f.interests.length >= 12) return toast('You can pick up to 12 interests.', 'error')
    if (!f.interests.some((i) => i.toLowerCase() === v.toLowerCase())) set('interests', [...f.interests, v])
    set('customInterest', '')
  }

  async function save(e: FormEvent) {
    e.preventDefault()
    const er: Record<string, string> = {}
    if (!NICKNAME_RE.test(f.nickname)) er.nickname = '3–20 characters: letters, numbers, underscore or dot.'
    if (f.bio.length > 300) er.bio = 'Bio must be 300 characters or less.'
    if (f.interested_in.length === 0) er.interested_in = 'Pick at least one option.'
    if (f.interests.length > 12) er.interests = 'Maximum 12 interests.'
    setErrors(er)
    if (Object.keys(er).length) return
    setBusy(true)
    const { error } = await supabase.from('profiles').update({
      nickname: f.nickname, bio: f.bio.trim(), area: f.area.trim() || null, avatar_url: f.avatar_url,
      gender_identity: f.gender[0], orientation: f.orientation[0],
      interested_in: f.interested_in, connection_types: f.connection_types, interests: f.interests,
      show_gender: f.show_gender, show_orientation: f.show_orientation, show_area: f.show_area && !!f.area.trim(),
    }).eq('id', session!.user.id)
    setBusy(false)
    if (error) {
      if (/duplicate|unique/i.test(error.message)) setErrors({ nickname: 'That nickname is taken.' })
      else toast(errMsg(error), 'error')
      return
    }
    await refreshProfile()
    toast('Profile updated ✨', 'success')
    nav('/profile')
  }

  return (
    <form onSubmit={save} className="space-y-5 pb-4">
      <h1 className="text-2xl font-black">Edit profile</h1>

      <div className="card flex items-center gap-4 p-4">
        <Avatar url={f.avatar_url} name={f.nickname || '?'} size={80} />
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn-primary !py-2" onClick={() => fileRef.current?.click()} disabled={uploading}>{uploading ? 'Uploading…' : 'Upload photo'}</button>
            {f.avatar_url && <button type="button" className="btn-ghost !py-2" onClick={() => set('avatar_url', null)}>Use avatar</button>}
          </div>
          <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={onPhoto} />
          <p className="hint">JPG/PNG/WebP, max 3 MB. No nudity or other people's photos. You can also keep the colorful avatar.</p>
        </div>
      </div>

      <div className="card space-y-5 p-5">
        <div>
          <label className="label" htmlFor="nick">Nickname</label>
          <input id="nick" className="input" value={f.nickname} maxLength={20} onChange={(e) => set('nickname', e.target.value)} />
          {errors.nickname && <p className="error-text">{errors.nickname}</p>}
        </div>
        <div>
          <label className="label" htmlFor="bio">Bio</label>
          <textarea id="bio" className="input min-h-[96px]" maxLength={300} value={f.bio} onChange={(e) => set('bio', e.target.value)} placeholder="A few words about you…" />
          <p className="hint">{f.bio.length}/300</p>
          {errors.bio && <p className="error-text">{errors.bio}</p>}
        </div>
        <div>
          <label className="label" htmlFor="area">General area (optional)</label>
          <input id="area" className="input" value={f.area} maxLength={60} onChange={(e) => set('area', e.target.value)} placeholder="e.g. Bohol, or Central Visayas" />
          <p className="hint">Type a city or region only. ChitChat never tracks your GPS or exact location.</p>
        </div>
      </div>

      <div className="card space-y-5 p-5">
        <div><span className="label">Gender identity</span><ChipSelect single options={GENDER_IDENTITIES} value={f.gender} onChange={(v) => set('gender', v)} /></div>
        <div><span className="label">Sexual orientation</span><ChipSelect single options={ORIENTATIONS} value={f.orientation} onChange={(v) => set('orientation', v)} /></div>
        <div>
          <span className="label">Who do you want to meet?</span>
          <ChipSelect options={INTERESTED_IN} value={f.interested_in} onChange={(v) => set('interested_in', v)} />
          {errors.interested_in && <p className="error-text">{errors.interested_in}</p>}
        </div>
        <div><span className="label">Looking for</span><ChipSelect options={CONNECTION_TYPES} value={f.connection_types} onChange={(v) => set('connection_types', v)} /></div>
      </div>

      <div className="card space-y-3 p-5">
        <span className="label">Interests &amp; hobbies</span>
        <ChipSelect options={[...new Set([...INTEREST_OPTIONS, ...f.interests])]} value={f.interests} onChange={(v) => set('interests', v)} />
        <div className="flex gap-2">
          <input className="input" placeholder="Add your own…" value={f.customInterest} maxLength={24} onChange={(e) => set('customInterest', e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addCustom() } }} aria-label="Add custom interest" />
          <button type="button" className="btn-ghost" onClick={addCustom}>Add</button>
        </div>
        {errors.interests && <p className="error-text">{errors.interests}</p>}
      </div>

      <div className="card divide-y divide-slate-200 px-5 dark:divide-white/10">
        <h2 className="py-3 text-sm font-bold">Show on my public profile</h2>
        <Switch label="Gender identity" checked={f.show_gender} onChange={(v) => set('show_gender', v)} />
        <Switch label="Sexual orientation" hint="Off by default." checked={f.show_orientation} onChange={(v) => set('show_orientation', v)} />
        <Switch label="General area" checked={f.show_area} onChange={(v) => set('show_area', v)} />
      </div>

      <div className="flex gap-3">
        <button type="button" className="btn-ghost flex-1" onClick={() => nav('/profile')}>Cancel</button>
        <button className="btn-primary flex-1" disabled={busy || uploading}>{busy ? 'Saving…' : 'Save changes'}</button>
      </div>
    </form>
  )
}
