import { FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Modal, Switch } from '../components/ui'
import { errMsg, validatePassword } from '../lib/utils'
import type { MyProfile } from '../lib/types'

type Flag = 'show_gender' | 'show_orientation' | 'show_photo' | 'show_area' | 'show_online' | 'allow_messages' | 'require_match_to_chat'

export default function Settings() {
  const { profile, session, refreshProfile, signOut } = useAuth()
  const toast = useToast()
  const nav = useNavigate()
  const p = profile!
  const [pw, setPw] = useState({ next: '', confirm: '' })
  const [pwBusy, setPwBusy] = useState(false)
  const [delOpen, setDelOpen] = useState(false)
  const [delText, setDelText] = useState('')
  const [delBusy, setDelBusy] = useState(false)

  async function toggle(k: Flag, v: boolean) {
    const patch: Partial<MyProfile> = { [k]: v }
    const { error } = await supabase.from('profiles').update(patch).eq('id', session!.user.id)
    if (error) return toast(errMsg(error), 'error')
    await refreshProfile()
  }

  async function changePw(e: FormEvent) {
    e.preventDefault()
    const ve = validatePassword(pw.next)
    if (ve) return toast(ve, 'error')
    if (pw.next !== pw.confirm) return toast('Passwords do not match.', 'error')
    setPwBusy(true)
    const { error } = await supabase.auth.updateUser({ password: pw.next })
    setPwBusy(false)
    if (error) return toast(errMsg(error), 'error')
    setPw({ next: '', confirm: '' })
    toast('Password updated 🔒', 'success')
  }

  async function deleteAccount() {
    setDelBusy(true)
    const { error } = await supabase.rpc('delete_my_account')
    if (error) { setDelBusy(false); return toast(errMsg(error), 'error') }
    await signOut()
    toast('Your account and data were deleted.', 'success')
    nav('/', { replace: true })
  }

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-black">Settings &amp; privacy</h1>

      <section className="card divide-y divide-slate-200 px-5 dark:divide-white/10">
        <h2 className="py-3 text-sm font-bold">Profile visibility</h2>
        <Switch label="Show my gender identity" checked={p.show_gender} onChange={(v) => toggle('show_gender', v)} />
        <Switch label="Show my sexual orientation" checked={p.show_orientation} onChange={(v) => toggle('show_orientation', v)} />
        <Switch label="Show my profile photo" hint="When off, others see your colorful avatar." checked={p.show_photo} onChange={(v) => toggle('show_photo', v)} />
        <Switch label="Show my general area" hint={p.area ? undefined : 'Add an area in Edit profile first.'} checked={p.show_area} onChange={(v) => toggle('show_area', v && !!p.area)} />
        <Switch label="Show when I'm online" checked={p.show_online} onChange={(v) => toggle('show_online', v)} />
      </section>

      <section className="card divide-y divide-slate-200 px-5 dark:divide-white/10">
        <h2 className="py-3 text-sm font-bold">Messaging</h2>
        <Switch label="Allow people to message me" hint="Turn off to pause all new messages." checked={p.allow_messages} onChange={(v) => toggle('allow_messages', v)} />
        <Switch label="Only chat after we match" hint="Strongly recommended. Both people must like each other first." checked={p.require_match_to_chat} onChange={(v) => toggle('require_match_to_chat', v)} />
      </section>

      <section className="card p-5">
        <h2 className="mb-3 text-sm font-bold">Change password</h2>
        <form onSubmit={changePw} className="space-y-3">
          <input type="password" className="input" placeholder="New password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} aria-label="New password" />
          <input type="password" className="input" placeholder="Confirm new password" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} aria-label="Confirm new password" />
          <button className="btn-primary" disabled={pwBusy || !pw.next}>{pwBusy ? 'Saving…' : 'Update password'}</button>
        </form>
      </section>

      <section className="card divide-y divide-slate-200 px-5 dark:divide-white/10">
        <Link to="/safety" className="flex items-center justify-between py-4 text-sm font-medium">🚫 Blocked users &amp; my reports <span>→</span></Link>
        <Link to="/guidelines" className="flex items-center justify-between py-4 text-sm font-medium">📜 Community guidelines <span>→</span></Link>
        <Link to="/profile/edit" className="flex items-center justify-between py-4 text-sm font-medium">✏️ Edit profile <span>→</span></Link>
      </section>

      <section className="card p-5 text-xs text-slate-500">
        <p><b className="text-slate-700 dark:text-slate-300">Signed in as</b> {session?.user.email}. Only you can see this.</p>
        <p className="mt-2">Anonymity is not a guarantee against identification. Don't share sensitive personal information in chats.</p>
      </section>

      <div className="flex flex-col gap-3 sm:flex-row">
        <button className="btn-ghost flex-1" onClick={async () => { await signOut(); nav('/', { replace: true }) }}>Log out</button>
        <button className="btn-ghost flex-1 !border-red-500/50 !text-red-500" onClick={() => setDelOpen(true)}>Delete account</button>
      </div>

      <Modal open={delOpen} onClose={() => setDelOpen(false)} title="Delete your account?">
        <p className="text-sm text-slate-600 dark:text-slate-300">This permanently deletes your profile, likes, matches, messages, photos' links and notifications. <b>It cannot be undone.</b></p>
        <label className="label mt-4" htmlFor="del">Type <b>DELETE</b> to confirm</label>
        <input id="del" className="input" value={delText} onChange={(e) => setDelText(e.target.value)} autoComplete="off" />
        <div className="mt-5 flex gap-3">
          <button className="btn-ghost flex-1" onClick={() => setDelOpen(false)}>Cancel</button>
          <button className="btn-danger flex-1" disabled={delText !== 'DELETE' || delBusy} onClick={deleteAccount}>{delBusy ? 'Deleting…' : 'Delete forever'}</button>
        </div>
      </Modal>
    </div>
  )
}
