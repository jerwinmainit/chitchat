import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { Conversation, PublicProfile } from '../lib/types'
import { useAuth } from '../context/AuthContext'
import { Avatar, EmptyState, ErrorBox, Spinner } from '../components/ui'
import { getPublicProfiles } from '../lib/api'
import { errMsg, timeAgo } from '../lib/utils'

export default function Chats() {
  const { session } = useAuth()
  const me = session!.user.id
  const [convs, setConvs] = useState<Conversation[]>([])
  const [people, setPeople] = useState<Record<string, PublicProfile>>({})
  const [unread, setUnread] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true)
    setError('')
    try {
      const [c, u] = await Promise.all([
        supabase.from('conversations').select('*').order('last_message_at', { ascending: false }),
        supabase.from('messages').select('conversation_id').neq('sender_id', me).is('read_at', null),
      ])
      if (c.error) throw c.error
      const mine = ((c.data ?? []) as Conversation[]).filter((x) => (x.user_a === me ? !x.a_hidden : !x.b_hidden))
      setConvs(mine)
      const counts: Record<string, number> = {}
      for (const m of (u.data ?? []) as { conversation_id: string }[]) counts[m.conversation_id] = (counts[m.conversation_id] ?? 0) + 1
      setUnread(counts)
      setPeople(await getPublicProfiles(mine.map((x) => (x.user_a === me ? x.user_b : x.user_a))))
    } catch (e) { setError(errMsg(e)) } finally { setLoading(false) }
  }, [me])

  useEffect(() => {
    void load()
    const ch = supabase.channel('chat-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, () => void load(true))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => void load(true))
      .subscribe()
    return () => { void supabase.removeChannel(ch) }
  }, [load])

  return (
    <div>
      <h1 className="mb-4 text-2xl font-black">Chats</h1>
      {loading ? <Spinner /> : error ? <ErrorBox message={error} onRetry={() => load()} /> : convs.length === 0 ? (
        <EmptyState icon="💬" title="No chats yet" text="Match with someone, then say hi! Your conversations will show up here." action={<Link to="/discover" className="btn-primary">Find people</Link>} />
      ) : (
        <ul className="space-y-2">
          {convs.map((c) => {
            const other = people[c.user_a === me ? c.user_b : c.user_a]
            if (!other) return null
            const n = unread[c.id] ?? 0
            return (
              <li key={c.id}>
                <Link to={`/chats/${c.id}`} className="card flex animate-rise items-center gap-3 p-3 transition hover:bg-slate-50 dark:hover:bg-white/5">
                  <Avatar url={other.avatar_url} name={other.nickname} size={54} online={other.is_online} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate font-bold">{other.nickname}</p>
                      <span className="shrink-0 text-[11px] text-slate-500">{c.last_message_preview ? timeAgo(c.last_message_at) : ''}</span>
                    </div>
                    <p className={`truncate text-sm ${n ? 'font-semibold' : 'text-slate-500'}`}>{c.last_message_preview || 'You matched! Say hi 👋'}</p>
                  </div>
                  {n > 0 && <span className="flex h-6 min-w-6 items-center justify-center rounded-full bg-hot px-1.5 text-xs font-bold text-white">{n}</span>}
                </Link>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
