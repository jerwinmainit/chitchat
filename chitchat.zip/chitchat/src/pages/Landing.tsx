import { Link } from 'react-router-dom'
import { Logo, ThemeToggle } from '../components/ui'

const FEATURES = [
  { icon: '🕶️', title: 'Stay anonymous', text: 'Use a nickname. You choose what others can see: gender, orientation, photo, area, online status.' },
  { icon: '💜', title: 'Match your way', text: 'Say who you want to meet and what you are looking for: friends, dating, or just chat.' },
  { icon: '⚡', title: 'Real-time chat', text: 'Private messages with read receipts, emojis and photos, only after a mutual match if you want.' },
  { icon: '🛡️', title: 'Safety first', text: '18+ only. Block and report in one tap. Delete your account and data anytime.' },
]

export default function Landing() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-electric/30 blur-3xl" />
      <div className="pointer-events-none absolute -right-24 top-40 h-96 w-96 rounded-full bg-hot/25 blur-3xl" />
      <div className="pointer-events-none absolute left-1/3 top-[500px] h-80 w-80 rounded-full bg-violet/25 blur-3xl" />

      <header className="relative mx-auto flex max-w-5xl items-center justify-between px-5 py-5">
        <Logo />
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link to="/login" className="btn-ghost">Log in</Link>
        </div>
      </header>

      <main className="relative mx-auto max-w-5xl px-5">
        <section className="animate-rise py-14 text-center sm:py-24">
          <span className="chip mb-5 !border-violet/40 !text-violet">18+ only · Private · Inclusive</span>
          <h1 className="text-4xl font-black leading-tight tracking-tight sm:text-6xl">
            ChitChat — <span className="text-gradient">Meet. Match. Chat.</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-base text-slate-600 dark:text-slate-300 sm:text-lg">
            Meet new people, make friends and find someone special, while keeping your real identity to yourself.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/signup" className="btn-primary !px-8 !py-3.5 text-base">Create free account</Link>
            <Link to="/login" className="btn-ghost !px-8 !py-3.5 text-base">I already have one</Link>
          </div>
        </section>

        <section className="grid gap-4 pb-16 sm:grid-cols-2">
          {FEATURES.map((f) => (
            <div key={f.title} className="card p-6 transition hover:-translate-y-1">
              <div className="mb-3 text-3xl">{f.icon}</div>
              <h3 className="text-lg font-bold">{f.title}</h3>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{f.text}</p>
            </div>
          ))}
        </section>

        <section className="card mb-12 p-6 text-sm text-slate-600 dark:text-slate-400">
          <h3 className="mb-1 font-bold text-slate-900 dark:text-white">A note about anonymity</h3>
          Nicknames protect your identity, but no online service can guarantee you can never be identified. Avoid sharing your
          full name, address, workplace, school, or financial details in chats. Read our <Link to="/guidelines" className="text-electric underline">community guidelines</Link>.
        </section>
      </main>

      <footer className="relative border-t border-slate-200 py-6 text-center text-xs text-slate-500 dark:border-white/10">
        © {new Date().getFullYear()} ChitChat · <Link to="/guidelines" className="underline">Community guidelines</Link> · Adults 18+ only
      </footer>
    </div>
  )
}
