import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { PublicProfile } from '../lib/types'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import ProfileCard from '../components/ProfileCard'
import { ChipSelect, EmptyState, ErrorBox, Modal, Spinner } from '../components/ui'
import { CONNECTION_TYPES, GENDER_IDENTITIES, INTEREST_OPTIONS, ORIENTATIONS } from '../lib/constants'
import { openConversation, sendLike, toggleFavorite } from '../lib/api'
import { errMsg } from '../lib/utils'

interface Filters { min: number; max: number; genders: string[]; orientations: string[]; interests: string[]; connections: string[] }
const DEFAULTS: Filters = { min: 18, max: 60, genders: [], orientations: [], interests: [], connections: [] }

export default function Discover() {
  const { session } = useAuth()
  const toast = useToast()
  const nav = useNavigate()
  const me = session!.user.id
  const [queue, setQueue] = useState<PublicProfile[]>([])
  const [favs, setFavs] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [filters, setFilters] = useState<Filters>(DEFAULTS)
  const [draft, setDraft] = useState<Filters>(DEFAULTS)
  const [open, setOpen] = useState(false)

  const load = useCallback(async (f: Filters) => {
    setLoading(true); setError('')
    const [res, fav] = await Promise.all([
      supabase.rpc('discover_profiles', {
        p_min_age: f.min, p_max_age: f.max, p_genders: f.genders, p_orientations: f.orientations,
        p_interests: f.interests, p_connections: f.connections, p_limit: 30,
      }),
      supabase.from('favorites').select('target_id').eq('user_id', me),
    ])
    if (res.error) setError(errMsg(res.error))
    else setQueue((res.data ?? []) as PublicProfile[])
    setFavs(new Set(((fav.data ?? []) as { target_id: string }[]).map((x) => x.target_id)))
    setLoading(false)
  }, [me])

  useEffect(() => { void load(filters) }, [load, filters])

  const current = queue[0]
  const next = () => setQueue((q) => q.slice(1))

  async function act(kind: 'like' | 'pass') {
    if (!current) return
    setBusy(true)
    try {
      const matched = await sendLike(me, current.id, kind)
      if (matched) toast(`It's a match with ${current.nickname}! 🎉`, 'success')
      else if (kind === 'like') toast('Liked 💜', 'info')
      next()
    } catch (e) { toast(errMsg(e), 'error') } finally { setBusy(false) }
  }

  async function fav() {
    if (!current) return
    const on = !favs.has(current.id)
    try {
      await toggleFavorite(me, current.id, on)
      setFavs((s) => { const n = new Set(s); if (on) n.add(current.id); else n.delete(current.id); return n })
      toast(on ? 'Added to favorites ⭐' : 'Removed from favorites', 'info')
    } catch (e) { toast(errMsg(e), 'error') }
  }

  async function chat() {
    if (!current) return
    try { nav(`/chats/${await openConversation(current.id)}`) } catch (e) { toast(errMsg(e), 'error') }
  }

  const active = JSON.stringify(filters) !== JSON.stringify(DEFAULTS)

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-black">Discover</h1>
        <button className="btn-ghost relative" onClick={() => { setDraft(filters); setOpen(true) }}>
          ⚙️ Filters{active && <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-hot" />}
        </button>
      </div>

      {loading ? <Spinner label="Finding people for you…" />
        : error ? <ErrorBox message={error} onRetry={() => load(filters)} />
        : current ? (
          <>
            <ProfileCard key={current.id} p={current} busy={busy} isFavorite={favs.has(current.id)} onLike={() => act('like')} onPass={() => act('pass')} onFavorite={fav} onChat={chat} />
            <p className="mt-3 text-center text-xs text-slate-500">{queue.length - 1} more {queue.length - 1 === 1 ? 'person' : 'people'} in your queue</p>
          </>
        ) : (
          <EmptyState icon="🌙" title="You're all caught up" text="No more profiles match right now. Try widening your filters, or check back later." action={
            <div className="flex gap-2">
              {active && <button className="btn-ghost" onClick={() => setFilters(DEFAULTS)}>Reset filters</button>}
              <button className="btn-primary" onClick={() => load(filters)}>Refresh</button>
            </div>} />
        )}

      <Modal open={open} onClose={() => setOpen(false)} title="Filters">
        <div className="space-y-5">
          <div>
            <span className="label">Age range: {draft.min} – {draft.max}{draft.max >= 99 ? '+' : ''}</span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="hint" htmlFor="amin">Min</label>
                <input id="amin" type="number" min={18} max={99} className="input" value={draft.min} onChange={(e) => setDraft({ ...draft, min: Math.max(18, Number(e.target.value) || 18) })} />
              </div>
              <div>
                <label className="hint" htmlFor="amax">Max</label>
                <input id="amax" type="number" min={18} max={99} className="input" value={draft.max} onChange={(e) => setDraft({ ...draft, max: Math.min(99, Number(e.target.value) || 99) })} />
              </div>
            </div>
          </div>
          <div><span className="label">Gender identity</span><ChipSelect options={GENDER_IDENTITIES.filter((g) => g !== 'Prefer not to say')} value={draft.genders} onChange={(v) => setDraft({ ...draft, genders: v })} /><p className="hint">Only people who show this on their profile can match a filter.</p></div>
          <div><span className="label">Sexual orientation</span><ChipSelect options={ORIENTATIONS.filter((g) => g !== 'Prefer not to say')} value={draft.orientations} onChange={(v) => setDraft({ ...draft, orientations: v })} /></div>
          <div><span className="label">Interests</span><ChipSelect options={INTEREST_OPTIONS} value={draft.interests} onChange={(v) => setDraft({ ...draft, interests: v })} /></div>
          <div><span className="label">Looking for</span><ChipSelect options={CONNECTION_TYPES} value={draft.connections} onChange={(v) => setDraft({ ...draft, connections: v })} /></div>
          <div className="flex gap-3">
            <button className="btn-ghost flex-1" onClick={() => setDraft(DEFAULTS)}>Reset</button>
            <button className="btn-primary flex-1" onClick={() => { if (draft.min > draft.max) { toast('Min age cannot be higher than max age.', 'error'); return } setFilters(draft); setOpen(false) }}>Apply</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
