import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { PublicProfile } from '../lib/types'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, ErrorBox, Spinner } from '../components/ui'
import ProfileCard from '../components/ProfileCard'
import ReportModal from '../components/ReportModal'
import { getPublicProfiles, openConversation, sendLike, toggleFavorite } from '../lib/api'
import { ageFromDob, errMsg, gradientFor } from '../lib/utils'

function Row({ k, v, shown }: { k: string; v: string; shown: boolean }) {
  return (
    <div className="flex items-center justify-between py-2.5 text-sm">
      <span className="text-slate-500">{k}</span>
      <span className="flex items-center gap-2 font-medium">{v || '—'} <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${shown ? 'bg-emerald-500/15 text-emerald-500' : 'bg-slate-500/15 text-slate-500'}`}>{shown ? 'Public' : 'Hidden'}</span></span>
    </div>
  )
}

export default function Profile() {
  const { id } = useParams<{ id: string }>()
  const { session, profile } = useAuth()
  const me = session!.user.id
  if (!id || id === me) return profile ? <OwnProfile /> : <Spinner />
  return <OtherProfile id={id} me={me} />
}

function OwnProfile() {
  const { profile: p } = useAuth()
  const me = p!
  return (
    <div className="space-y-4">
      <div className="card overflow-hidden">
        <div className="h-28" style={{ background: gradientFor(me.nickname) }} />
        <div className="-mt-12 px-5 pb-5">
          <div className="rounded-full border-4 border-white dark:border-navy-800 inline-block"><Avatar url={me.avatar_url} name={me.nickname} size={96} /></div>
          <h1 className="mt-2 text-2xl font-black">{me.nickname}, {ageFromDob(me.birth_date)}</h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{me.bio || 'Add a short bio so people can get to know you.'}</p>
          {me.interests.length > 0 && <div className="mt-3 flex flex-wrap gap-1.5">{me.interests.map((i) => <span key={i} className="chip !py-1">{i}</span>)}</div>}
          <div className="mt-4 flex gap-2">
            <Link to="/profile/edit" className="btn-primary flex-1">Edit profile</Link>
            <Link to="/settings" className="btn-ghost flex-1">Settings & privacy</Link>
          </div>
        </div>
      </div>

      <div className="card divide-y divide-slate-200 px-5 py-2 dark:divide-white/10">
        <h2 className="py-3 text-sm font-bold">What others can see</h2>
        <Row k="Photo" v={me.avatar_url ? 'Uploaded' : 'Avatar'} shown={me.show_photo} />
        <Row k="Gender identity" v={me.gender_identity} shown={me.show_gender} />
        <Row k="Orientation" v={me.orientation} shown={me.show_orientation} />
        <Row k="General area" v={me.area ?? ''} shown={me.show_area && !!me.area} />
        <Row k="Online status" v="" shown={me.show_online} />
        <p className="py-3 text-xs text-slate-500">Your email, password and exact location are never shown to anyone.</p>
      </div>

      <div className="card p-5 text-sm">
        <p><b>Interested in:</b> {me.interested_in.join(', ') || '—'}</p>
        <p className="mt-1"><b>Looking for:</b> {me.connection_types.join(', ') || '—'}</p>
      </div>
    </div>
  )
}

function OtherProfile({ id, me }: { id: string; me: string }) {
  const nav = useNavigate()
  const toast = useToast()
  const [p, setP] = useState<PublicProfile | null>(null)
  const [fav, setFav] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [report, setReport] = useState(false)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const [prof, f] = await Promise.all([
        getPublicProfiles([id]),
        supabase.from('favorites').select('target_id').eq('user_id', me).eq('target_id', id).maybeSingle(),
      ])
      setP(prof[id] ?? null)
      setFav(Boolean(f.data))
    } catch (e) { setError(errMsg(e)) } finally { setLoading(false) }
  }, [id, me])

  useEffect(() => { void load() }, [load])

  if (loading) return <Spinner />
  if (error) return <ErrorBox message={error} onRetry={load} />
  if (!p) return <ErrorBox message="This profile is not available." />

  return (
    <div className="space-y-4">
      <button className="btn-ghost" onClick={() => nav(-1)}>← Back</button>
      <ProfileCard
        p={p} busy={busy} isFavorite={fav}
        onLike={async () => { setBusy(true); try { const m = await sendLike(me, p.id, 'like'); toast(m ? `It's a match! 🎉` : 'Liked 💜', 'success') } catch (e) { toast(errMsg(e), 'error') } finally { setBusy(false) } }}
        onFavorite={async () => { try { await toggleFavorite(me, p.id, !fav); setFav(!fav) } catch (e) { toast(errMsg(e), 'error') } }}
        onChat={async () => { try { nav(`/chats/${await openConversation(p.id)}`) } catch (e) { toast(errMsg(e), 'error') } }}
      />
      <div className="flex gap-2">
        <button className="btn-ghost flex-1" onClick={() => setReport(true)}>🚩 Report</button>
        <button className="btn-ghost flex-1 !text-red-500" onClick={async () => {
          if (!window.confirm(`Block ${p.nickname}?`)) return
          const { error: err } = await supabase.from('blocks').insert({ blocker_id: me, blocked_id: p.id })
          if (err && !/duplicate/i.test(err.message)) return toast(errMsg(err), 'error')
          toast(`${p.nickname} blocked.`, 'success'); nav('/discover', { replace: true })
        }}>🚫 Block</button>
      </div>
      <ReportModal open={report} onClose={() => setReport(false)} targetId={p.id} targetName={p.nickname} onBlocked={() => nav('/discover', { replace: true })} />
    </div>
  )
}
