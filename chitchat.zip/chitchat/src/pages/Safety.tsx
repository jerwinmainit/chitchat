import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { ReportRow } from '../lib/types'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, ErrorBox, Spinner } from '../components/ui'
import { REPORT_REASONS } from '../lib/constants'
import { errMsg, timeAgo } from '../lib/utils'

interface Blocked { id: string; nickname: string; avatar_url: string | null; blocked_at: string }

export default function Safety() {
  const { session } = useAuth()
  const me = session!.user.id
  const toast = useToast()
  const [blocked, setBlocked] = useState<Blocked[]>([])
  const [reports, setReports] = useState<ReportRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true); setError('')
    const [b, r] = await Promise.all([
      supabase.rpc('my_blocked_users'),
      supabase.from('reports').select('id,reported_nickname,reason,details,status,created_at').eq('reporter_id', me).order('created_at', { ascending: false }),
    ])
    if (b.error || r.error) setError(errMsg(b.error ?? r.error))
    else { setBlocked((b.data ?? []) as Blocked[]); setReports((r.data ?? []) as ReportRow[]) }
    setLoading(false)
  }, [me])

  useEffect(() => { void load() }, [load])

  async function unblock(u: Blocked) {
    const { error: err } = await supabase.from('blocks').delete().eq('blocker_id', me).eq('blocked_id', u.id)
    if (err) return toast(errMsg(err), 'error')
    toast(`${u.nickname} unblocked.`, 'success')
    setBlocked((x) => x.filter((i) => i.id !== u.id))
  }

  const label = (v: string) => REPORT_REASONS.find((r) => r.value === v)?.label ?? v
  const badge: Record<string, string> = { open: 'bg-amber-500/15 text-amber-500', reviewing: 'bg-sky-500/15 text-sky-500', resolved: 'bg-emerald-500/15 text-emerald-500', dismissed: 'bg-slate-500/15 text-slate-500' }

  if (loading) return <Spinner />
  if (error) return <ErrorBox message={error} onRetry={load} />

  return (
    <div className="space-y-6">
      <div>
        <Link to="/settings" className="text-sm text-slate-500">← Settings</Link>
        <h1 className="mt-1 text-2xl font-black">Blocked users &amp; reports</h1>
      </div>

      <section>
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-500">Blocked users</h2>
        {blocked.length === 0 ? <p className="card p-5 text-sm text-slate-500">You haven't blocked anyone. 🙌</p> : (
          <ul className="space-y-2">
            {blocked.map((u) => (
              <li key={u.id} className="card flex items-center gap-3 p-3">
                <Avatar url={u.avatar_url} name={u.nickname} size={44} />
                <div className="min-w-0 flex-1"><p className="truncate font-semibold">{u.nickname}</p><p className="text-xs text-slate-500">Blocked {timeAgo(u.blocked_at)}</p></div>
                <button className="btn-ghost !py-2" onClick={() => unblock(u)}>Unblock</button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-500">My reports</h2>
        {reports.length === 0 ? <p className="card p-5 text-sm text-slate-500">You haven't reported anyone. To report, open a profile or chat and choose Report.</p> : (
          <ul className="space-y-2">
            {reports.map((r) => (
              <li key={r.id} className="card p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-semibold">{r.reported_nickname}</p>
                  <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold capitalize ${badge[r.status] ?? badge.open}`}>{r.status}</span>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-300">{label(r.reason)}</p>
                {r.details && <p className="mt-1 text-xs text-slate-500">“{r.details}”</p>}
                <p className="mt-1 text-[11px] text-slate-400">{timeAgo(r.created_at)}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
