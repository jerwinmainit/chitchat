import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { PublicProfile } from '../lib/types'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, EmptyState, ErrorBox, Spinner } from '../components/ui'
import { getPublicProfiles, openConversation, sendLike, toggleFavorite } from '../lib/api'
import { errMsg } from '../lib/utils'

type Tab = 'matches' | 'liked' | 'favorites'

export default function Matches() {
  const { session } = useAuth()
  const me = session!.user.id
  const toast = useToast()
  const nav = useNavigate()
  const [tab, setTab] = useState<Tab>('matches')
  const [data, setData] = useState<Record<Tab, PublicProfile[]>>({ matches: [], liked: [], favorites: [] })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const [m, incoming, mine, fav] = await Promise.all([
        supabase.from('matches').select('user_a,user_b'),
        supabase.from('likes').select('liker_id').eq('liked_id', me).eq('action', 'like'),
        supabase.from('likes').select('liked_id').eq('liker_id', me),
        supabase.from('favorites').select('target_id').eq('user_id', me),
      ])
      for (const r of [m, incoming, mine, fav]) if (r.error) throw r.error
      const matchIds = ((m.data ?? []) as { user_a: string; user_b: string }[]).map((x) => (x.user_a === me ? x.user_b : x.user_a))
      const acted = new Set(((mine.data ?? []) as { liked_id: string }[]).map((x) => x.liked_id))
      const likedIds = ((incoming.data ?? []) as { liker_id: string }[]).map((x) => x.liker_id).filter((id) => !acted.has(id))
      const favIds = ((fav.data ?? []) as { target_id: string }[]).map((x) => x.target_id)
      const profiles = await getPublicProfiles([...new Set([...matchIds, ...likedIds, ...favIds])])
      const pick = (ids: string[]) => ids.map((i) => profiles[i]).filter(Boolean)
      setData({ matches: pick(matchIds), liked: pick(likedIds), favorites: pick(favIds) })
    } catch (e) { setError(errMsg(e)) } finally { setLoading(false) }
  }, [me])

  useEffect(() => { void load() }, [load])

  async function likeBack(p: PublicProfile) {
    try {
      const matched = await sendLike(me, p.id, 'like')
      toast(matched ? `It's a match with ${p.nickname}! 🎉` : 'Liked 💜', 'success')
      void load()
    } catch (e) { toast(errMsg(e), 'error') }
  }
  async function pass(p: PublicProfile) {
    try { await sendLike(me, p.id, 'pass'); void load() } catch (e) { toast(errMsg(e), 'error') }
  }
  async function chat(p: PublicProfile) {
    try { nav(`/chats/${await openConversation(p.id)}`) } catch (e) { toast(errMsg(e), 'error') }
  }
  async function unfav(p: PublicProfile) {
    try { await toggleFavorite(me, p.id, false); void load() } catch (e) { toast(errMsg(e), 'error') }
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'matches', label: `Matches${data.matches.length ? ` (${data.matches.length})` : ''}` },
    { id: 'liked', label: `Liked you${data.liked.length ? ` (${data.liked.length})` : ''}` },
    { id: 'favorites', label: 'Favorites' },
  ]
  const list = data[tab]

  return (
    <div>
      <h1 className="mb-4 text-2xl font-black">Likes</h1>
      <div className="mb-4 grid grid-cols-3 gap-1 rounded-full bg-slate-200 p-1 dark:bg-white/10" role="tablist">
        {tabs.map((t) => (
          <button key={t.id} role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)} className={`rounded-full py-2 text-xs font-semibold transition ${tab === t.id ? 'bg-brand text-white shadow' : 'text-slate-600 dark:text-slate-300'}`}>{t.label}</button>
        ))}
      </div>

      {loading ? <Spinner /> : error ? <ErrorBox message={error} onRetry={load} /> : list.length === 0 ? (
        <EmptyState
          icon={tab === 'matches' ? '💞' : tab === 'liked' ? '👀' : '⭐'}
          title={tab === 'matches' ? 'No matches yet' : tab === 'liked' ? 'Nobody new yet' : 'No favorites yet'}
          text={tab === 'matches' ? 'When you and someone else like each other, you will match here.' : tab === 'liked' ? 'People who like you will show up here.' : 'Tap the star on a profile to save it.'}
          action={<Link to="/discover" className="btn-primary">Go discover</Link>}
        />
      ) : (
        <ul className="space-y-3">
          {list.map((p) => (
            <li key={p.id} className="card flex animate-rise items-center gap-3 p-3">
              <Link to={`/u/${p.id}`}><Avatar url={p.avatar_url} name={p.nickname} size={56} online={p.is_online} /></Link>
              <Link to={`/u/${p.id}`} className="min-w-0 flex-1">
                <p className="truncate font-bold">{p.nickname}, {p.age}</p>
                <p className="truncate text-xs text-slate-500">{p.bio || p.interests.slice(0, 3).join(' · ') || 'No bio yet'}</p>
              </Link>
              {tab === 'matches' && <button className="btn-primary !px-4" onClick={() => chat(p)}>Chat</button>}
              {tab === 'liked' && (<>
                <button className="btn-ghost h-10 w-10 !p-0" onClick={() => pass(p)} aria-label={`Pass on ${p.nickname}`}>✕</button>
                <button className="btn-primary h-10 w-10 !p-0" onClick={() => likeBack(p)} aria-label={`Like ${p.nickname} back`}>♥</button>
              </>)}
              {tab === 'favorites' && (<>
                <button className="btn-ghost h-10 w-10 !p-0" onClick={() => unfav(p)} aria-label="Remove from favorites">⭐</button>
                <button className="btn-primary !px-4" onClick={() => chat(p)}>Chat</button>
              </>)}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
