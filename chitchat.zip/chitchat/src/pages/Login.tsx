import { FormEvent, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { Logo, ThemeToggle } from '../components/ui'
import { EMAIL_RE } from '../lib/utils'
import { useToast } from '../context/ToastContext'

export default function Login() {
  const nav = useNavigate()
  const loc = useLocation()
  const toast = useToast()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault()
    setError('')
    if (!EMAIL_RE.test(email)) return setError('Enter a valid email address.')
    if (!password) return setError('Enter your password.')
    setBusy(true)
    const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
    setBusy(false)
    if (err) {
      setError(/confirm/i.test(err.message) ? 'Please confirm your email first (check your inbox).' : 'Wrong email or password.')
      return
    }
    const from = (loc.state as { from?: string } | null)?.from
    nav(from && from !== '/' ? from : '/discover', { replace: true })
  }

  async function forgot() {
    if (!EMAIL_RE.test(email)) return setError('Type your email above first, then click "Forgot password".')
    const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: window.location.origin + '/login' })
    if (err) setError(err.message)
    else toast('Password reset email sent (if the account exists).', 'success')
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-8">
      <div className="mb-6 flex items-center justify-between"><Logo /><ThemeToggle /></div>
      <h1 className="text-3xl font-black">Welcome back 👋</h1>
      <p className="mt-1 text-sm text-slate-500">Log in to continue chatting.</p>
      <form onSubmit={submit} className="card mt-5 space-y-4 p-5" noValidate>
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        </div>
        <div>
          <label className="label" htmlFor="password">Password</label>
          <input id="password" type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
        </div>
        {error && <p className="error-text" role="alert">{error}</p>}
        <button className="btn-primary w-full !py-3.5" disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
        <button type="button" onClick={forgot} className="w-full text-center text-xs text-slate-500 underline">Forgot password?</button>
      </form>
      <p className="mt-5 text-center text-sm text-slate-500">New here? <Link to="/signup" className="font-semibold text-electric">Create an account</Link></p>
    </div>
  )
}
