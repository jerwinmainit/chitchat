import { Link, useNavigate } from 'react-router-dom'
import { Logo } from '../components/ui'

const RULES = [
  ['Adults only', 'ChitChat is strictly for people aged 18 and above. Accounts that appear to belong to minors are removed.'],
  ['Be respectful', 'No harassment, hate speech, threats, bullying, or pressure. Respect "no" and unmatched or blocked people.'],
  ['Be real about who you are', 'No impersonation or fake identities. Do not pretend to be someone else, or use another person\'s photos.'],
  ['No scams or spam', 'Never ask for money, gift cards, or financial details. Do not advertise or send repeated unsolicited messages.'],
  ['Keep content appropriate', 'No sexually explicit photos, nudity of any kind in profile photos, graphic violence, or illegal content. Never share images of other people without their consent.'],
  ['Protect your privacy', 'Anonymity helps, but is not a guarantee. Do not share your full name, address, workplace, school, ID numbers, or passwords. Meeting in person? Choose a public place and tell a friend.'],
  ['Report problems', 'Use Block and Report on any profile or chat. We review every report. Serious violations lead to permanent bans.'],
]

export default function Guidelines() {
  const nav = useNavigate()
  return (
    <div className="mx-auto max-w-2xl px-5 py-8">
      <div className="mb-6 flex items-center justify-between">
        <Logo />
        <button onClick={() => nav(-1)} className="btn-ghost">← Back</button>
      </div>
      <h1 className="text-3xl font-black">Community guidelines</h1>
      <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">Para safe ug masaya ang tanan. These rules keep ChitChat friendly for everyone.</p>
      <ol className="mt-6 space-y-3">
        {RULES.map(([t, d], i) => (
          <li key={t} className="card p-4">
            <h2 className="font-bold"><span className="text-gradient">{i + 1}.</span> {t}</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{d}</p>
          </li>
        ))}
      </ol>
      <p className="mt-6 text-sm"><Link to="/signup" className="text-electric underline">Create an account</Link></p>
    </div>
  )
}
