import { ChangeEvent, FormEvent, useCallback, useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import type { Conversation, Message, PublicProfile } from '../lib/types'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, ErrorBox, Modal, Spinner } from '../components/ui'
import ReportModal from '../components/ReportModal'
import { getPublicProfiles } from '../lib/api'
import { clockTime, dayLabel, errMsg } from '../lib/utils'

const EMOJIS = ['😀', '😂', '🥰', '😍', '😘', '😎', '🤔', '😅', '😭', '🥺', '😉', '🙈', '👍', '🙏', '👏', '🔥', '💜', '💙', '💖', '🎉', '✨', '🌈', '☕', '🍕', '🎶', '👋', '😴', '🤗']
const IMG_TYPES = ['image/jpeg', 'image/png', 'image/webp']

function Ticks({ m }: { m: Message }) {
  if (m.read_at) return <span className="text-sky-300" title="Read">✓✓</span>
  if (m.delivered_at) return <span title="Delivered">✓✓</span>
  return <span title="Sent">✓</span>
}

export default function ChatRoom() {
  const { id } = useParams<{ id: string }>()
  const { session } = useAuth()
  const me = session!.user.id
  const nav = useNavigate()
  const toast = useToast()
  const [conv, setConv] = useState<Conversation | null>(null)
  const [other, setOther] = useState<PublicProfile | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [sending, setSending] = useState(false)
  const [emojiOpen, setEmojiOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [reportOpen, setReportOpen] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [urls, setUrls] = useState<Record<string, string>>({})
  const [revealed, setRevealed] = useState<Set<string>>(new Set())
  const bottom = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const markRead = useCallback(() => {
    if (id) void supabase.rpc('mark_read', { conv: id })
  }, [id])

  const resolveImages = useCallback(async (list: Message[]) => {
    const paths = list.filter((m) => m.image_path).map((m) => m.image_path as string)
    if (!paths.length) return
    const { data } = await supabase.storage.from('chat-images').createSignedUrls(paths, 3600)
    if (!data) return
    setUrls((u) => {
      const n = { ...u }
      for (const d of data) if (d.path && d.signedUrl) n[d.path] = d.signedUrl
      return n
    })
  }, [])

  const load = useCallback(async () => {
    if (!id) return
    setLoading(true); setError('')
    try {
      const { data: c, error: ce } = await supabase.from('conversations').select('*').eq('id', id).maybeSingle()
      if (ce) throw ce
      if (!c) { setError('This conversation is not available.'); return }
      setConv(c as Conversation)
      const otherId = c.user_a === me ? c.user_b : c.user_a
      const [profiles, msgs] = await Promise.all([
        getPublicProfiles([otherId]),
        supabase.from('messages').select('*').eq('conversation_id', id).order('created_at', { ascending: true }).limit(300),
      ])
      if (msgs.error) throw msgs.error
      setOther(profiles[otherId] ?? null)
      setMessages(msgs.data as Message[])
      void resolveImages(msgs.data as Message[])
      markRead()
    } catch (e) { setError(errMsg(e)) } finally { setLoading(false) }
  }, [id, me, markRead, resolveImages])

  useEffect(() => { void load() }, [load])

  // realtime: new messages + delivery/read updates
  useEffect(() => {
    if (!id) return
    const ch = supabase.channel(`conv-${id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${id}` }, (payload) => {
        const m = payload.new as Message
        setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]))
        if (m.image_path) void resolveImages([m])
        if (m.sender_id !== me) markRead()
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${id}` }, (payload) => {
        const m = payload.new as Message
        setMessages((prev) => prev.map((x) => (x.id === m.id ? { ...x, ...m } : x)))
      })
      .subscribe()
    return () => { void supabase.removeChannel(ch) }
  }, [id, me, markRead, resolveImages])

  // keep the other person's online dot fresh
  useEffect(() => {
    if (!conv) return
    const otherId = conv.user_a === me ? conv.user_b : conv.user_a
    const t = setInterval(async () => {
      const p = await getPublicProfiles([otherId])
      if (p[otherId]) setOther(p[otherId])
    }, 60_000)
    return () => clearInterval(t)
  }, [conv, me])

  useEffect(() => { bottom.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages.length])

  async function send(e?: FormEvent) {
    e?.preventDefault()
    const body = text.trim()
    if (!body || !id || sending) return
    setSending(true)
    const { data, error: err } = await supabase.from('messages').insert({ conversation_id: id, sender_id: me, body }).select().single()
    setSending(false)
    if (err) return toast(/Too many/i.test(err.message) ? 'You are sending messages too fast. Slow down a bit.' : /row-level|policy/i.test(err.message) ? 'You can no longer message this user.' : errMsg(err), 'error')
    setText(''); setEmojiOpen(false)
    setMessages((prev) => (prev.some((x) => x.id === (data as Message).id) ? prev : [...prev, data as Message]))
    inputRef.current?.focus()
  }

  async function onPickImage(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file || !id) return
    if (!IMG_TYPES.includes(file.type)) return toast('Only JPG, PNG or WebP images are allowed.', 'error')
    if (file.size > 5 * 1024 * 1024) return toast('Image is too large (max 5 MB).', 'error')
    setSending(true)
    try {
      const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg'
      const path = `${id}/${me}-${Date.now()}.${ext}`
      const up = await supabase.storage.from('chat-images').upload(path, file, { contentType: file.type })
      if (up.error) throw up.error
      const { data, error: err } = await supabase.from('messages').insert({ conversation_id: id, sender_id: me, image_path: path }).select().single()
      if (err) throw err
      setMessages((prev) => (prev.some((x) => x.id === (data as Message).id) ? prev : [...prev, data as Message]))
      void resolveImages([data as Message])
    } catch (err) { toast(errMsg(err), 'error') } finally { setSending(false) }
  }

  async function block() {
    if (!other) return
    if (!window.confirm(`Block ${other.nickname}? You won't see each other or be able to message.`)) return
    const { error: err } = await supabase.from('blocks').insert({ blocker_id: me, blocked_id: other.id })
    if (err && !/duplicate/i.test(err.message)) return toast(errMsg(err), 'error')
    toast(`${other.nickname} blocked.`, 'success')
    nav('/chats', { replace: true })
  }

  async function deleteConv() {
    if (!id) return
    const { error: err } = await supabase.rpc('hide_conversation', { conv: id })
    if (err) return toast(errMsg(err), 'error')
    toast('Conversation deleted from your inbox.', 'success')
    nav('/chats', { replace: true })
  }

  if (loading) return <Spinner />
  if (error || !conv || !other) return <ErrorBox message={error || 'Conversation not found.'} onRetry={load} />

  let lastDay = ''
  return (
    <div className="-mx-4 -mt-5 flex h-[calc(100dvh-68px-72px)] flex-col md:mx-0 md:mt-0 md:h-[calc(100dvh-100px)]">
      {/* header */}
      <div className="flex items-center gap-3 border-b border-slate-200 px-4 py-3 dark:border-white/10">
        <Link to="/chats" className="text-xl" aria-label="Back to chats">←</Link>
        <Link to={`/u/${other.id}`} className="flex min-w-0 flex-1 items-center gap-3">
          <Avatar url={other.avatar_url} name={other.nickname} size={40} online={other.is_online} />
          <div className="min-w-0">
            <p className="truncate font-bold leading-tight">{other.nickname}</p>
            <p className="text-xs text-slate-500">{other.is_online ? 'Online' : 'Offline'}</p>
          </div>
        </Link>
        <div className="relative">
          <button className="btn-ghost h-10 w-10 !p-0 text-lg" onClick={() => setMenuOpen((o) => !o)} aria-label="Chat options" aria-expanded={menuOpen}>⋮</button>
          {menuOpen && (
            <div className="card absolute right-0 top-12 z-20 w-52 animate-pop overflow-hidden py-1 text-sm" onClick={() => setMenuOpen(false)}>
              <Link to={`/u/${other.id}`} className="block px-4 py-2.5 hover:bg-slate-100 dark:hover:bg-white/10">View profile</Link>
              <button onClick={() => setReportOpen(true)} className="block w-full px-4 py-2.5 text-left hover:bg-slate-100 dark:hover:bg-white/10">Report</button>
              <button onClick={block} className="block w-full px-4 py-2.5 text-left text-red-500 hover:bg-slate-100 dark:hover:bg-white/10">Block</button>
              <button onClick={() => setConfirmDelete(true)} className="block w-full px-4 py-2.5 text-left text-red-500 hover:bg-slate-100 dark:hover:bg-white/10">Delete conversation</button>
            </div>
          )}
        </div>
      </div>

      {/* messages */}
      <div className="flex-1 space-y-1 overflow-y-auto px-4 py-4">
        <p className="mx-auto mb-3 max-w-xs rounded-xl bg-violet/10 px-3 py-2 text-center text-[11px] text-violet">
          🔒 Keep it safe: don't share your address, ID numbers, passwords or money details.
        </p>
        {messages.length === 0 && <p className="py-10 text-center text-sm text-slate-500">No messages yet. Say hi to {other.nickname} 👋</p>}
        {messages.map((m) => {
          const mine = m.sender_id === me
          const d = dayLabel(m.created_at)
          const showDay = d !== lastDay
          lastDay = d
          const url = m.image_path ? urls[m.image_path] : undefined
          const hidden = !mine && m.image_path && !revealed.has(m.id)
          return (
            <div key={m.id}>
              {showDay && <p className="my-3 text-center text-[11px] font-semibold uppercase tracking-wide text-slate-400">{d}</p>}
              <div className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-3xl px-4 py-2.5 text-sm shadow-sm ${mine ? 'rounded-br-md bg-brand text-white' : 'rounded-bl-md bg-slate-200 text-slate-900 dark:bg-navy-700 dark:text-slate-100'}`}>
                  {m.image_path && (
                    url ? (
                      hidden ? (
                        <button onClick={() => setRevealed((s) => new Set(s).add(m.id))} className="relative block overflow-hidden rounded-2xl" aria-label="Tap to view photo">
                          <img src={url} alt="Hidden photo" className="h-40 w-52 object-cover blur-2xl" />
                          <span className="absolute inset-0 flex items-center justify-center bg-black/30 text-xs font-semibold text-white">Tap to view photo</span>
                        </button>
                      ) : (
                        <a href={url} target="_blank" rel="noreferrer noopener"><img src={url} alt="Shared photo" className="max-h-64 rounded-2xl object-cover" /></a>
                      )
                    ) : <div className="h-24 w-40 animate-pulse rounded-2xl bg-black/10" />
                  )}
                  {m.body && <p className="whitespace-pre-wrap break-words">{m.body}</p>}
                  <p className={`mt-1 flex items-center justify-end gap-1 text-[10px] ${mine ? 'text-white/70' : 'text-slate-500'}`}>
                    {clockTime(m.created_at)} {mine && <Ticks m={m} />}
                  </p>
                </div>
              </div>
            </div>
          )
        })}
        <div ref={bottom} />
      </div>

      {/* composer */}
      <div className="border-t border-slate-200 p-3 dark:border-white/10">
        {emojiOpen && (
          <div className="card mb-2 grid animate-pop grid-cols-7 gap-1 p-2 text-2xl sm:grid-cols-10">
            {EMOJIS.map((em) => <button key={em} type="button" className="rounded-lg p-1 hover:bg-slate-100 dark:hover:bg-white/10" onClick={() => { setText((t) => t + em); inputRef.current?.focus() }}>{em}</button>)}
          </div>
        )}
        <form onSubmit={send} className="flex items-center gap-2">
          <button type="button" className="btn-ghost h-11 w-11 shrink-0 !p-0 text-xl" onClick={() => setEmojiOpen((o) => !o)} aria-label="Emoji">😊</button>
          <button type="button" className="btn-ghost h-11 w-11 shrink-0 !p-0 text-xl" onClick={() => fileRef.current?.click()} disabled={sending} aria-label="Send a photo">📷</button>
          <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={onPickImage} />
          <input ref={inputRef} className="input !rounded-full" value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message…" maxLength={2000} aria-label="Message" />
          <button className="btn-primary h-11 w-11 shrink-0 !p-0 text-lg" disabled={!text.trim() || sending} aria-label="Send">➤</button>
        </form>
      </div>

      <ReportModal open={reportOpen} onClose={() => setReportOpen(false)} targetId={other.id} targetName={other.nickname} onBlocked={() => nav('/chats', { replace: true })} />
      <Modal open={confirmDelete} onClose={() => setConfirmDelete(false)} title="Delete conversation?">
        <p className="text-sm text-slate-600 dark:text-slate-300">This removes the chat from <b>your</b> inbox only. {other.nickname} keeps their copy.</p>
        <div className="mt-5 flex gap-3">
          <button className="btn-ghost flex-1" onClick={() => setConfirmDelete(false)}>Cancel</button>
          <button className="btn-danger flex-1" onClick={deleteConv}>Delete</button>
        </div>
      </Modal>
    </div>
  )
}
