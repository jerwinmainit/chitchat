import { FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { Logo, ThemeToggle, ChipSelect } from '../components/ui'
import { CONNECTION_TYPES, GENDER_IDENTITIES, INTERESTED_IN, ORIENTATIONS } from '../lib/constants'
import { EMAIL_RE, NICKNAME_RE, errMsg, isAdult, maxDobForAdult, passwordStrength, validatePassword } from '../lib/utils'
import { useToast } from '../context/ToastContext'

type Errors = Partial<Record<string, string>>

export default function SignUp() {
  const nav = useNavigate()
  const toast = useToast()
  const [f, setF] = useState({
    nickname: '', email: '', password: '', confirm: '', dob: '',
    gender: ['Prefer not to say'], orientation: ['Prefer not to say'],
    interestedIn: [] as string[], connections: [] as string[],
    adult: false, rules: false,
  })
  const [errors, setErrors] = useState<Errors>({})
  const [busy, setBusy] = useState(false)
  const [confirmSent, setConfirmSent] = useState(false)
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }))

  async function submit(e: FormEvent) {
    e.preventDefault()
    const er: Errors = {}
    if (!NICKNAME_RE.test(f.nickname)) er.nickname = '3–20 characters: letters, numbers, underscore or dot.'
    if (!EMAIL_RE.test(f.email)) er.email = 'Enter a valid email address.'
    const pe = validatePassword(f.password)
    if (pe) er.password = pe
    if (f.confirm !== f.password) er.confirm = 'Passwords do not match.'
    if (!f.dob) er.dob = 'Date of birth is required.'
    else if (!isAdult(f.dob)) er.dob = 'You must be 18 or older to join ChitChat.'
    if (f.interestedIn.length === 0) er.interestedIn = 'Pick at least one option.'
    if (!f.adult) er.adult = 'Please confirm that you are 18 or older.'
    if (!f.rules) er.rules = 'Please agree to the community guidelines.'
    setErrors(er)
    if (Object.keys(er).length) return

    setBusy(true)
    try {
      const { data: free, error: nerr } = await supabase.rpc('nickname_available', { n: f.nickname })
      if (nerr) throw nerr
      if (!free) { setErrors({ nickname: 'That nickname is taken. Try another one.' }); return }

      const { data, error } = await supabase.auth.signUp({
        email: f.email.trim(),
        password: f.password,
        options: {
          data: {
            nickname: f.nickname,
            birth_date: f.dob,
            gender_identity: f.gender[0],
            orientation: f.orientation[0],
            interested_in: f.interestedIn,
            connection_types: f.connections,
          },
        },
      })
      if (error) throw error
      if (data.session) {
        toast('Welcome to ChitChat! 🎉', 'success')
        nav('/profile/edit', { replace: true })
      } else {
        setConfirmSent(true)
      }
    } catch (err) {
      const m = errMsg(err)
      toast(/18 or older/i.test(m) ? 'You must be 18 or older to use ChitChat.' : m, 'error')
    } finally {
      setBusy(false)
    }
  }

  if (confirmSent) {
    return (
      <div className="mx-auto flex min-h-screen max-w-md items-center p-5">
        <div className="card animate-pop p-8 text-center">
          <div className="text-5xl">📬</div>
          <h1 className="mt-3 text-2xl font-extrabold">Check your email</h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">We sent a confirmation link to <b>{f.email}</b>. Click it, then log in. Check spam too.</p>
          <Link to="/login" className="btn-primary mt-6">Go to login</Link>
        </div>
      </div>
    )
  }

  const strength = passwordStrength(f.password)
  const bar = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-emerald-500', 'bg-emerald-500'][strength]

  return (
    <div className="mx-auto max-w-lg px-5 py-6">
      <div className="mb-6 flex items-center justify-between"><Logo /><ThemeToggle /></div>
      <h1 className="text-3xl font-black">Join <span className="text-gradient">ChitChat</span></h1>
      <p className="mt-1 text-sm text-slate-500">Free forever. Adults 18+ only.</p>

      <form onSubmit={submit} className="card mt-5 space-y-5 p-5" noValidate>
        <div>
          <label className="label" htmlFor="nickname">Nickname</label>
          <input id="nickname" className="input" value={f.nickname} onChange={(e) => set('nickname', e.target.value)} autoComplete="username" placeholder="e.g. sunset_wanderer" maxLength={20} />
          <p className="hint">Not your real name. This is what others see.</p>
          {errors.nickname && <p className="error-text">{errors.nickname}</p>}
        </div>

        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" type="email" className="input" value={f.email} onChange={(e) => set('email', e.target.value)} autoComplete="email" placeholder="you@example.com" />
          <p className="hint">Never shown to other users.</p>
          {errors.email && <p className="error-text">{errors.email}</p>}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" className="input" value={f.password} onChange={(e) => set('password', e.target.value)} autoComplete="new-password" />
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10"><div className={`h-full transition-all ${bar}`} style={{ width: `${(strength / 4) * 100}%` }} /></div>
            {errors.password ? <p className="error-text">{errors.password}</p> : <p className="hint">8+ chars, upper &amp; lowercase, number.</p>}
          </div>
          <div>
            <label className="label" htmlFor="confirm">Confirm password</label>
            <input id="confirm" type="password" className="input" value={f.confirm} onChange={(e) => set('confirm', e.target.value)} autoComplete="new-password" />
            {errors.confirm && <p className="error-text">{errors.confirm}</p>}
          </div>
        </div>

        <div>
          <label className="label" htmlFor="dob">Date of birth</label>
          <input id="dob" type="date" className="input" max={maxDobForAdult()} min="1900-01-01" value={f.dob} onChange={(e) => set('dob', e.target.value)} />
          <p className="hint">Only your age is shown, never your birth date. It cannot be changed later.</p>
          {errors.dob && <p className="error-text">{errors.dob}</p>}
        </div>

        <div>
          <span className="label">Gender identity</span>
          <ChipSelect single options={GENDER_IDENTITIES} value={f.gender} onChange={(v) => set('gender', v)} />
        </div>

        <div>
          <span className="label">Sexual orientation</span>
          <ChipSelect single options={ORIENTATIONS} value={f.orientation} onChange={(v) => set('orientation', v)} />
          <p className="hint">Separate from gender identity. You decide later if either one is visible on your profile.</p>
        </div>

        <div>
          <span className="label">Who do you want to meet?</span>
          <ChipSelect options={INTERESTED_IN} value={f.interestedIn} onChange={(v) => set('interestedIn', v)} />
          {errors.interestedIn && <p className="error-text">{errors.interestedIn}</p>}
        </div>

        <div>
          <span className="label">What are you looking for? (optional)</span>
          <ChipSelect options={CONNECTION_TYPES} value={f.connections} onChange={(v) => set('connections', v)} />
        </div>

        <div className="space-y-2 text-sm">
          <label className="flex items-start gap-2"><input type="checkbox" className="mt-0.5 h-4 w-4 accent-violet" checked={f.adult} onChange={(e) => set('adult', e.target.checked)} /> I confirm that I am 18 years old or older.</label>
          {errors.adult && <p className="error-text">{errors.adult}</p>}
          <label className="flex items-start gap-2"><input type="checkbox" className="mt-0.5 h-4 w-4 accent-violet" checked={f.rules} onChange={(e) => set('rules', e.target.checked)} /> I agree to the <Link to="/guidelines" target="_blank" className="text-electric underline">community guidelines</Link> and understand that anonymity is not a guarantee against identification.</label>
          {errors.rules && <p className="error-text">{errors.rules}</p>}
        </div>

        <button className="btn-primary w-full !py-3.5" disabled={busy}>{busy ? 'Creating account…' : 'Create account'}</button>
        <p className="text-center text-sm text-slate-500">Already a member? <Link to="/login" className="font-semibold text-electric">Log in</Link></p>
      </form>
    </div>
  )
}
