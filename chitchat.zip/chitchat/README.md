ChitChat: Meet. Match. Chat.

An 18+ anonymous social and dating web app.
Stack: React + TypeScript + Tailwind CSS + Supabase (Auth, PostgreSQL, Realtime, Storage) + Vercel.

IMPORTANT: this project has not been deployed or run end to end yet. Follow the steps below to put it online.
Do not share your link until you have tested sign up, chat and delete account yourself.


WHAT YOU NEED (all free)
- Node.js 18 or newer (nodejs.org)
- A Supabase account (supabase.com)
- A GitHub account (github.com)
- A Vercel account (vercel.com), sign in with GitHub


STEP 1. Run it on your computer

1. Open a terminal in the chitchat folder.
2. Install packages:   npm install
3. Do Steps 2 and 3 below first (Supabase), then come back here.
4. Copy .env.example to .env and fill in the two values (Step 3).
5. Start the app:      npm run dev
6. Open http://localhost:5173 in Google Chrome.


STEP 2. Create the Supabase backend (database)

1. Go to supabase.com, click "New project". Pick a name (example: chitchat), a strong database password, and the region nearest you (Singapore is good for the Philippines). Wait about 2 minutes.
2. In the left menu click "SQL Editor", then "New query".
3. Open the file supabase/schema.sql, copy ALL of it, paste it in the editor, and click "Run". You should see "Success". This creates every table, the security rules, the photo storage, and the real-time chat.
   If you see an error, run the file again from a fresh project, or send me the error message.
4. Turn on realtime (only if chat does not update live): Database -> Replication, make sure the tables messages, notifications, conversations and matches are enabled. The schema file already does this.


STEP 3. Get your keys (the safe ones)

1. In Supabase click Project Settings -> API.
2. Copy "Project URL" and paste it as VITE_SUPABASE_URL in your .env file.
3. Copy the "anon public" key and paste it as VITE_SUPABASE_ANON_KEY.
4. NEVER use or share the "service_role" key. This app does not need it. The anon key is safe in the browser because Row Level Security protects the data.


STEP 4. Email settings (Authentication)

- For quick testing: Authentication -> Providers -> Email -> turn OFF "Confirm email". Then you can sign up and log in right away.
- For real use: leave "Confirm email" ON. Users must click the link in their email. Supabase's built-in email sender is limited to a few emails per hour, so for a real launch add your own SMTP (Authentication -> SMTP Settings).
- After you have your Vercel link (Step 6), go to Authentication -> URL Configuration:
  Site URL = your Vercel link, and add the same link to "Redirect URLs".


STEP 5. Test locally (checklist)

1. Sign up with two different emails (use two browsers, or one normal window and one private window).
2. Try a birth date under 18. It must be rejected.
3. Log in as user A and user B. In Discover, press the heart on each other. You should get "It's a match".
4. Open Chats, send messages. They should appear instantly on the other side, with ticks for sent, delivered and read.
5. Try block, report, delete conversation, edit profile, upload a photo, and Settings -> Delete account.


STEP 6. Put it online (Vercel)

1. Create a new empty repository on github.com (private is fine).
2. In your terminal, inside the chitchat folder:
     git init
     git add .
     git commit -m "ChitChat first version"
     git branch -M main
     git remote add origin https://github.com/YOUR-USERNAME/chitchat.git
     git push -u origin main
   (The .env file is NOT uploaded. That is correct and safe.)
3. Go to vercel.com -> Add New -> Project -> import your chitchat repository.
4. Framework preset: Vite (it is detected automatically). Build command: npm run build. Output: dist.
5. Open "Environment Variables" and add:
     VITE_SUPABASE_URL       = your Project URL
     VITE_SUPABASE_ANON_KEY  = your anon public key
6. Click Deploy. In about a minute you get a link like https://chitchat-yourname.vercel.app
   You can change the name in Project Settings -> Domains.
7. Do Step 4's last part (Site URL and Redirect URLs) with this link.
8. Open the link in Google Chrome and test again.

Every time you push new code to GitHub, Vercel updates the site automatically.


HOW PRIVACY AND SAFETY WORK

- Nickname only. Email and password are never shown. Passwords are hashed by Supabase Auth.
- Other users read profiles only through the public_profiles database view. Hidden details (gender, orientation, area, photo, online status) come back empty, so they cannot be seen even by inspecting network calls.
- Blocked users disappear from each other's Discover, matches, chats and notifications, in both directions.
- Age 18+ is checked in the signup form AND by a database trigger. Birth date cannot be edited afterwards.
- Row Level Security is on for every table. Users can only read or change their own data and conversations they are part of.
- Rate limits (in the database): 120 likes per hour, 30 messages per minute, 10 reports per day.
- Chat photos are stored in a private bucket, shown through short-lived signed links, and are blurred until the receiver taps them.
- Location: the app never uses GPS. "General area" is plain text typed by the user, and only shown if they turn it on.
- Delete account (Settings) removes the user and cascades to profile, likes, matches, messages and notifications. Reports are kept without a link to the deleted account, for safety.
- The app tells users that anonymity is not a guarantee against identification.


REVIEWING REPORTS (for you as the owner)

Open Supabase -> Table Editor -> reports. Change "status" to reviewing, resolved or dismissed. Users see the status on their Blocked and Reports page. To ban someone, find their row in auth.users (Authentication -> Users) and use "Ban user" or delete them.


IMPORTANT BEFORE A PUBLIC LAUNCH

This is a solid starting point, but a real dating app also needs: a privacy policy and terms (check the Philippine Data Privacy Act of 2012), image moderation for uploaded photos, a captcha on signup (Supabase Authentication -> Attack Protection), your own SMTP, and a monitoring plan for reports. Age checks based on a typed birth date can be falsified, so treat them as a minimum, not as proof.


FOLDER GUIDE

supabase/schema.sql       whole database, security rules, storage, realtime
src/lib                   Supabase client, types, helpers
src/context               auth, theme, toast notifications
src/components            layout with bottom navigation, cards, modals
src/pages                 Landing, SignUp, Login, Discover, Profile, Matches (Likes), Chats, ChatRoom, Notifications, EditProfile, Settings, Safety (Blocked and Reports), Guidelines


COMMON PROBLEMS

- Screen says "Almost there": the .env values are missing. Add them and restart npm run dev (or add them in Vercel and redeploy).
- "Invalid login credentials": wrong password, or the email was not confirmed yet.
- No profiles in Discover: you need at least two accounts. Also check that your "Who do you want to meet" matches the other person's gender identity, and theirs matches yours.
- Photo upload fails: make sure schema.sql ran fully (it creates the avatars and chat-images buckets).
- Page refresh gives 404 on Vercel: keep vercel.json in the project root.
