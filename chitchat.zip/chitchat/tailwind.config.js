/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        navy: { 950: '#05060f', 900: '#0a0d1f', 800: '#11152e', 700: '#1a1f3f' },
        electric: '#2f7bff',
        violet: '#8b5cf6',
        hot: '#ff3d9a',
      },
      backgroundImage: {
        brand: 'linear-gradient(135deg, #2f7bff 0%, #8b5cf6 50%, #ff3d9a 100%)',
      },
      keyframes: {
        pop: { '0%': { transform: 'scale(.9)', opacity: '0' }, '100%': { transform: 'scale(1)', opacity: '1' } },
        rise: { '0%': { transform: 'translateY(12px)', opacity: '0' }, '100%': { transform: 'translateY(0)', opacity: '1' } },
      },
      animation: { pop: 'pop .25s ease-out', rise: 'rise .35s ease-out' },
    },
  },
  plugins: [],
}
