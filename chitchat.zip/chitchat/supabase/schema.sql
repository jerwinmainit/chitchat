-- ============================================================
-- ChitChat database schema for Supabase (PostgreSQL)
-- Run this whole file once in: Supabase dashboard -> SQL Editor -> New query -> Run
-- ============================================================

create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- 1. TABLES
-- ------------------------------------------------------------

-- "Users" = Supabase auth.users (email + hashed password live there, never exposed).
-- "Profiles" = public-facing data. Only the owner can read the raw row.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null unique check (nickname ~ '^[A-Za-z0-9_.]{3,20}$'),
  birth_date date not null,
  gender_identity text not null default 'Prefer not to say',
  orientation text not null default 'Prefer not to say',
  interested_in text[] not null default '{}',
  connection_types text[] not null default '{}',
  bio text not null default '' check (char_length(bio) <= 300),
  interests text[] not null default '{}',
  avatar_url text,
  area text check (area is null or char_length(area) <= 60),   -- general area only, e.g. "Tagbilaran" (typed by user)
  show_gender boolean not null default true,
  show_orientation boolean not null default false,
  show_area boolean not null default false,
  show_online boolean not null default true,
  show_photo boolean not null default true,
  allow_messages boolean not null default true,
  require_match_to_chat boolean not null default true,
  last_seen timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table public.likes (
  liker_id uuid not null references public.profiles(id) on delete cascade,
  liked_id uuid not null references public.profiles(id) on delete cascade,
  action text not null check (action in ('like','pass')),
  created_at timestamptz not null default now(),
  primary key (liker_id, liked_id),
  check (liker_id <> liked_id)
);

create table public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  target_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, target_id),
  check (user_id <> target_id)
);

-- user_a < user_b always, so each pair exists once
create table public.matches (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_a, user_b),
  check (user_a < user_b)
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now(),
  last_message_preview text not null default '',
  a_hidden boolean not null default false,   -- "deleted" from user_a's inbox
  b_hidden boolean not null default false,
  a_cleared_at timestamptz not null default 'epoch',  -- user_a no longer sees messages before this
  b_cleared_at timestamptz not null default 'epoch',
  unique (user_a, user_b),
  check (user_a < user_b)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text check (body is null or char_length(body) <= 2000),
  image_path text,
  created_at timestamptz not null default now(),
  delivered_at timestamptz,
  read_at timestamptz,
  check ((body is not null and char_length(btrim(body)) > 0) or image_path is not null)
);
create index messages_conv_idx on public.messages (conversation_id, created_at);

create table public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_id uuid references public.profiles(id) on delete set null,  -- kept even if reported user deletes account
  reported_nickname text not null,
  reason text not null check (reason in ('harassment','scam','impersonation','inappropriate_content','underage','spam','other')),
  details text not null default '' check (char_length(details) <= 1000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('like','match','message','system')),
  actor_id uuid references public.profiles(id) on delete cascade,
  text text not null default '',
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);

-- ------------------------------------------------------------
-- 2. HELPER FUNCTIONS
-- ------------------------------------------------------------

create or replace function public.is_blocked_between(a uuid, b uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.blocks
    where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a)
  );
$$;

create or replace function public.is_participant(conv uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.conversations c
    where c.id = conv and auth.uid() in (c.user_a, c.user_b)
  );
$$;

create or replace function public.my_cleared_at(conv uuid)
returns timestamptz language sql stable security definer set search_path = public as $$
  select case when auth.uid() = c.user_a then c.a_cleared_at else c.b_cleared_at end
  from public.conversations c where c.id = conv;
$$;

create or replace function public.can_send_in(conv uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.conversations c
    join public.profiles other on other.id = case when auth.uid() = c.user_a then c.user_b else c.user_a end
    where c.id = conv
      and auth.uid() in (c.user_a, c.user_b)
      and other.allow_messages
      and not public.is_blocked_between(c.user_a, c.user_b)
  );
$$;

create or replace function public.rate_limit(tbl text, uid uuid, max_count int, window_interval interval)
returns void language plpgsql security definer set search_path = public as $$
declare n int;
begin
  execute format('select count(*) from public.%I where %I = $1 and created_at > now() - $2',
    tbl,
    case tbl when 'likes' then 'liker_id' when 'messages' then 'sender_id' when 'reports' then 'reporter_id' else 'user_id' end)
    into n using uid, window_interval;
  if n >= max_count then
    raise exception 'Too many requests. Please slow down and try again later.' using errcode = 'P0001';
  end if;
end;
$$;

-- ------------------------------------------------------------
-- 3. NEW USER -> PROFILE (also enforces 18+ on the server)
-- ------------------------------------------------------------

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  meta jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  dob date;
begin
  begin
    dob := (meta->>'birth_date')::date;
  exception when others then
    raise exception 'A valid date of birth is required.';
  end;
  if dob is null or dob > (current_date - interval '18 years')::date then
    raise exception 'You must be 18 or older to use ChitChat.';
  end if;
  if dob < date '1900-01-01' then
    raise exception 'Invalid date of birth.';
  end if;

  insert into public.profiles (id, nickname, birth_date, gender_identity, orientation, interested_in, connection_types, interests)
  values (
    new.id,
    meta->>'nickname',
    dob,
    coalesce(nullif(meta->>'gender_identity',''), 'Prefer not to say'),
    coalesce(nullif(meta->>'orientation',''), 'Prefer not to say'),
    coalesce(array(select jsonb_array_elements_text(coalesce(meta->'interested_in','[]'::jsonb))), '{}'),
    coalesce(array(select jsonb_array_elements_text(coalesce(meta->'connection_types','[]'::jsonb))), '{}'),
    '{}'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Birth date can never be changed after signup (stops age-gate bypass)
create or replace function public.profiles_guard()
returns trigger language plpgsql as $$
begin
  if new.birth_date <> old.birth_date then
    raise exception 'Date of birth cannot be changed.';
  end if;
  return new;
end;
$$;
create trigger profiles_guard_trg before update on public.profiles
  for each row execute function public.profiles_guard();

-- ------------------------------------------------------------
-- 4. PUBLIC VIEW: what OTHER users are allowed to see
--    (hidden fields are returned as NULL; blocked users in either direction are removed)
-- ------------------------------------------------------------

create or replace view public.public_profiles as
select
  p.id,
  p.nickname,
  date_part('year', age(p.birth_date))::int as age,
  case when p.show_gender then p.gender_identity end as gender_identity,
  case when p.show_orientation then p.orientation end as orientation,
  p.bio,
  p.interests,
  p.connection_types,
  case when p.show_photo then p.avatar_url end as avatar_url,
  case when p.show_area then p.area end as area,
  (p.show_online and p.last_seen > now() - interval '3 minutes') as is_online
from public.profiles p
where p.id = auth.uid()
   or not public.is_blocked_between(auth.uid(), p.id);

revoke all on public.public_profiles from anon, public;
grant select on public.public_profiles to authenticated;

-- ------------------------------------------------------------
-- 5. ROW LEVEL SECURITY
-- ------------------------------------------------------------

alter table public.profiles enable row level security;
alter table public.likes enable row level security;
alter table public.favorites enable row level security;
alter table public.matches enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;
alter table public.notifications enable row level security;

-- profiles: you can read/update ONLY your own raw row (others use the public_profiles view)
create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- likes
create policy "likes_select" on public.likes for select to authenticated
  using (liker_id = auth.uid() or (liked_id = auth.uid() and action = 'like'));
create policy "likes_insert" on public.likes for insert to authenticated
  with check (liker_id = auth.uid() and not public.is_blocked_between(liker_id, liked_id));
create policy "likes_update" on public.likes for update to authenticated
  using (liker_id = auth.uid()) with check (liker_id = auth.uid() and not public.is_blocked_between(liker_id, liked_id));
create policy "likes_delete" on public.likes for delete to authenticated using (liker_id = auth.uid());

-- favorites (private to owner)
create policy "fav_select" on public.favorites for select to authenticated using (user_id = auth.uid());
create policy "fav_insert" on public.favorites for insert to authenticated
  with check (user_id = auth.uid() and not public.is_blocked_between(user_id, target_id));
create policy "fav_delete" on public.favorites for delete to authenticated using (user_id = auth.uid());

-- matches (read only; created by trigger)
create policy "matches_select" on public.matches for select to authenticated
  using (auth.uid() in (user_a, user_b) and not public.is_blocked_between(user_a, user_b));

-- conversations (read only; created / changed via functions)
create policy "conv_select" on public.conversations for select to authenticated
  using (auth.uid() in (user_a, user_b) and not public.is_blocked_between(user_a, user_b));

-- messages
create policy "msg_select" on public.messages for select to authenticated
  using (public.is_participant(conversation_id) and created_at > public.my_cleared_at(conversation_id));
create policy "msg_insert" on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and public.can_send_in(conversation_id));

-- blocks
create policy "blocks_select" on public.blocks for select to authenticated using (blocker_id = auth.uid());
create policy "blocks_insert" on public.blocks for insert to authenticated with check (blocker_id = auth.uid());
create policy "blocks_delete" on public.blocks for delete to authenticated using (blocker_id = auth.uid());

-- reports (you can file and read your own; staff review in the Supabase dashboard)
create policy "reports_select" on public.reports for select to authenticated using (reporter_id = auth.uid());
create policy "reports_insert" on public.reports for insert to authenticated
  with check (reporter_id = auth.uid() and reported_id <> auth.uid());

-- notifications (created by triggers only)
create policy "notif_select" on public.notifications for select to authenticated using (user_id = auth.uid());
create policy "notif_update" on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notif_delete" on public.notifications for delete to authenticated using (user_id = auth.uid());

-- Table-level privileges: nothing for anonymous visitors
revoke all on all tables in schema public from anon;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.likes to authenticated;
grant select, insert, delete on public.favorites to authenticated;
grant select on public.matches, public.conversations to authenticated;
grant select, insert on public.messages to authenticated;
grant select, insert, delete on public.blocks to authenticated;
grant select, insert on public.reports to authenticated;
grant select, update, delete on public.notifications to authenticated;

-- ------------------------------------------------------------
-- 6. TRIGGERS (rate limits, matching, notifications)
-- ------------------------------------------------------------

create or replace function public.notify(target uuid, kind text, actor uuid, msg text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if public.is_blocked_between(target, actor) then return; end if;
  -- avoid spamming: one unread notification per kind per actor
  if kind in ('like','message') and exists (
    select 1 from public.notifications where user_id = target and actor_id = actor and type = kind and not read
  ) then return; end if;
  insert into public.notifications (user_id, type, actor_id, text) values (target, kind, actor, msg);
end;
$$;

create or replace function public.likes_before()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    perform public.rate_limit('likes', new.liker_id, 120, interval '1 hour');
  end if;
  return new;
end;
$$;
create trigger likes_before_trg before insert on public.likes
  for each row execute function public.likes_before();

create or replace function public.likes_after()
returns trigger language plpgsql security definer set search_path = public as $$
declare a uuid; b uuid; new_match uuid;
begin
  if new.action <> 'like' then return new; end if;
  if exists (select 1 from public.likes where liker_id = new.liked_id and liked_id = new.liker_id and action = 'like') then
    a := least(new.liker_id, new.liked_id);
    b := greatest(new.liker_id, new.liked_id);
    insert into public.matches (user_a, user_b) values (a, b) on conflict do nothing returning id into new_match;
    if new_match is not null then
      insert into public.conversations (user_a, user_b) values (a, b) on conflict do nothing;
      insert into public.notifications (user_id, type, actor_id, text) values
        (new.liker_id, 'match', new.liked_id, 'It''s a match!'),
        (new.liked_id, 'match', new.liker_id, 'It''s a match!');
    end if;
  else
    perform public.notify(new.liked_id, 'like', new.liker_id, 'Someone liked your profile');
  end if;
  return new;
end;
$$;
create trigger likes_after_trg after insert or update on public.likes
  for each row execute function public.likes_after();

create or replace function public.messages_before()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.rate_limit('messages', new.sender_id, 30, interval '1 minute');
  new.delivered_at := null;
  new.read_at := null;
  return new;
end;
$$;
create trigger messages_before_trg before insert on public.messages
  for each row execute function public.messages_before();

create or replace function public.messages_after()
returns trigger language plpgsql security definer set search_path = public as $$
declare c public.conversations; other uuid;
begin
  select * into c from public.conversations where id = new.conversation_id;
  other := case when new.sender_id = c.user_a then c.user_b else c.user_a end;
  update public.conversations
    set last_message_at = new.created_at,
        last_message_preview = case when new.image_path is not null and new.body is null then '📷 Photo' else left(new.body, 80) end,
        a_hidden = false, b_hidden = false
    where id = new.conversation_id;
  perform public.notify(other, 'message', new.sender_id, 'You have a new message');
  return new;
end;
$$;
create trigger messages_after_trg after insert on public.messages
  for each row execute function public.messages_after();

create or replace function public.reports_before()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.rate_limit('reports', new.reporter_id, 10, interval '1 day');
  return new;
end;
$$;
create trigger reports_before_trg before insert on public.reports
  for each row execute function public.reports_before();

-- ------------------------------------------------------------
-- 7. FUNCTIONS THE APP CALLS (RPC)
-- ------------------------------------------------------------

-- Is this nickname free? (callable before signup)
create or replace function public.nickname_available(n text)
returns boolean language sql stable security definer set search_path = public as $$
  select not exists (select 1 from public.profiles where lower(nickname) = lower(n));
$$;
grant execute on function public.nickname_available(text) to anon, authenticated;

-- Discover: filters on REAL values server-side without leaking hidden ones
create or replace function public.discover_profiles(
  p_min_age int default 18,
  p_max_age int default 99,
  p_genders text[] default '{}',
  p_orientations text[] default '{}',
  p_interests text[] default '{}',
  p_connections text[] default '{}',
  p_limit int default 20
)
returns setof public.public_profiles
language sql stable security definer set search_path = public as $$
  with me as (select * from public.profiles where id = auth.uid())
  select pp.*
  from public.public_profiles pp
  join public.profiles p on p.id = pp.id
  cross join me
  where p.id <> me.id
    and date_part('year', age(p.birth_date)) between greatest(p_min_age, 18) and p_max_age
    and not exists (select 1 from public.likes l where l.liker_id = me.id and l.liked_id = p.id)
    -- mutual preference: do I want them, and do they want me?
    and (cardinality(me.interested_in) = 0 or 'Everyone' = any(me.interested_in)
         or p.gender_identity = any(me.interested_in) or p.gender_identity = 'Prefer not to say')
    and (cardinality(p.interested_in) = 0 or 'Everyone' = any(p.interested_in)
         or me.gender_identity = any(p.interested_in) or me.gender_identity = 'Prefer not to say')
    -- filters only apply to details the other person has chosen to show
    and (cardinality(p_genders) = 0 or (p.show_gender and p.gender_identity = any(p_genders)))
    and (cardinality(p_orientations) = 0 or (p.show_orientation and p.orientation = any(p_orientations)))
    and (cardinality(p_interests) = 0 or p.interests && p_interests)
    and (cardinality(p_connections) = 0 or p.connection_types && p_connections)
  order by p.last_seen desc
  limit least(p_limit, 50);
$$;
grant execute on function public.discover_profiles(int,int,text[],text[],text[],text[],int) to authenticated;

-- Start (or reopen) a chat with someone
create or replace function public.start_conversation(target uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); a uuid; b uuid; cid uuid; need_match boolean;
begin
  if me is null then raise exception 'Please log in.'; end if;
  if target = me then raise exception 'You cannot message yourself.'; end if;
  if not exists (select 1 from public.profiles where id = target) then raise exception 'User not found.'; end if;
  if public.is_blocked_between(me, target) then raise exception 'You cannot message this user.'; end if;
  if not (select allow_messages from public.profiles where id = target) then
    raise exception 'This user is not accepting messages.';
  end if;
  need_match := (select require_match_to_chat from public.profiles where id = target)
             or (select require_match_to_chat from public.profiles where id = me);
  a := least(me, target); b := greatest(me, target);
  if need_match and not exists (select 1 from public.matches where user_a = a and user_b = b) then
    raise exception 'You need to match with this person before chatting.';
  end if;
  insert into public.conversations (user_a, user_b) values (a, b) on conflict do nothing;
  select id into cid from public.conversations where user_a = a and user_b = b;
  update public.conversations
    set a_hidden = case when me = a then false else a_hidden end,
        b_hidden = case when me = b then false else b_hidden end
    where id = cid;
  return cid;
end;
$$;
grant execute on function public.start_conversation(uuid) to authenticated;

-- Delete a conversation from MY inbox only
create or replace function public.hide_conversation(conv uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.conversations set
    a_hidden = case when auth.uid() = user_a then true else a_hidden end,
    a_cleared_at = case when auth.uid() = user_a then now() else a_cleared_at end,
    b_hidden = case when auth.uid() = user_b then true else b_hidden end,
    b_cleared_at = case when auth.uid() = user_b then now() else b_cleared_at end
  where id = conv and auth.uid() in (user_a, user_b);
end;
$$;
grant execute on function public.hide_conversation(uuid) to authenticated;

-- Delivered / read receipts
create or replace function public.mark_delivered()
returns void language sql security definer set search_path = public as $$
  update public.messages m set delivered_at = now()
  from public.conversations c
  where m.conversation_id = c.id and auth.uid() in (c.user_a, c.user_b)
    and m.sender_id <> auth.uid() and m.delivered_at is null;
$$;
grant execute on function public.mark_delivered() to authenticated;

create or replace function public.mark_read(conv uuid)
returns void language sql security definer set search_path = public as $$
  update public.messages m set read_at = now(), delivered_at = coalesce(delivered_at, now())
  where m.conversation_id = conv and public.is_participant(conv)
    and m.sender_id <> auth.uid() and m.read_at is null;
$$;
grant execute on function public.mark_read(uuid) to authenticated;

-- Lists for the Blocked Users / Reports page
create or replace function public.my_blocked_users()
returns table (id uuid, nickname text, avatar_url text, blocked_at timestamptz)
language sql stable security definer set search_path = public as $$
  select p.id, p.nickname, case when p.show_photo then p.avatar_url end, b.created_at
  from public.blocks b join public.profiles p on p.id = b.blocked_id
  where b.blocker_id = auth.uid() order by b.created_at desc;
$$;
grant execute on function public.my_blocked_users() to authenticated;

-- Nickname lookup for people in my own likes/chats even if they blocked... (not needed) --

-- Full account + data deletion
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then raise exception 'Please log in.'; end if;
  delete from auth.users where id = auth.uid();   -- cascades to profile, likes, messages, etc.
end;
$$;
grant execute on function public.delete_my_account() to authenticated;

-- Lock down: remove default public execute on internal helpers
revoke execute on function public.rate_limit(text, uuid, int, interval) from public, anon, authenticated;
revoke execute on function public.notify(uuid, text, uuid, text) from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.likes_before() from public, anon, authenticated;
revoke execute on function public.likes_after() from public, anon, authenticated;
revoke execute on function public.messages_before() from public, anon, authenticated;
revoke execute on function public.messages_after() from public, anon, authenticated;
revoke execute on function public.reports_before() from public, anon, authenticated;

-- ------------------------------------------------------------
-- 8. STORAGE (photos)
-- ------------------------------------------------------------

-- Profile photos: public bucket, but only you can write inside your own folder
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 3145728, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

-- Chat images: PRIVATE bucket, only the two people in the conversation can open them
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('chat-images', 'chat-images', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "avatars_read" on storage.objects for select to authenticated
  using (bucket_id = 'avatars');
create policy "avatars_write" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars_update" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- chat-images path format: <conversation_id>/<your_user_id>-<timestamp>.<ext>
create policy "chatimg_read" on storage.objects for select to authenticated
  using (bucket_id = 'chat-images' and public.is_participant(((storage.foldername(name))[1])::uuid));
create policy "chatimg_write" on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-images'
    and public.can_send_in(((storage.foldername(name))[1])::uuid)
    and name like (storage.foldername(name))[1] || '/' || auth.uid()::text || '-%');
create policy "chatimg_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'chat-images'
    and public.is_participant(((storage.foldername(name))[1])::uuid)
    and name like (storage.foldername(name))[1] || '/' || auth.uid()::text || '-%');

-- ------------------------------------------------------------
-- 9. REALTIME (live chat, live notifications)
-- ------------------------------------------------------------

alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.conversations;
alter publication supabase_realtime add table public.matches;
